/**
 * @license Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */

CKEDITOR.plugins.setLang( 'uploadwidget', 'pt', {
	abort: 'Upload aborted by the user.', // MISSING
	doneOne: 'Ficheiro carregado com sucesso.',
	doneMany: 'Successfully uploaded %1 files.', // MISSING
	uploadOne: 'Uploading file ({percentage}%)...', // MISSING
	uploadMany: 'Uploading files, {current} of {max} done ({percentage}%)...' // MISSING
} );
