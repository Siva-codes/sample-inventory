<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Login | Inventory</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.5 -->
  <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css'); ?>">
  <!-- Font Awesome -->
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url('assets/css/AdminLTE.min.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/custom.css'); ?>">
  <!-- iCheck -->

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
      <![endif]-->
    </head>
    <body class="hold-transition login-page">
      <div class="login-box">      
        <div class="login-box-body">
          <div class="login-logo"><b>Inventory Management</b></div><!-- /.login-logo -->
          <?php echo alert(); ?>
          <form class="frm-login" method1="post" action1="<?=site_url('account/login'); ?>">
            <div class="form-group has-feedback">
              <input type="text" name="email" class="form-control" placeholder="Username" id ="email">
              <!-- <span class="fa fa-user form-control-feedback"></span> -->
            </div>
            <div class="form-group has-feedback">
              <input type="password" name="password" class="form-control" placeholder="Password" id="password">
              <!-- <span class="fa fa-lock form-control-feedback"></span> -->
            </div>
            <div style="width: 100%;text-align: center;">
              <div class="aj_msg"></div>
              <label class="err_lbl"></label><br>
              <button class="btn btn-gen" id="btn-login" title="Login" type="button"> Log In</button>
            </div>

          <!-- <div class="row">
            <div class="col-lg-offset-8 col-sm-offset-8 col-xs-offset-8 col-xs-4">
              <button type="submit" class="btn btn-primary btn-block btn-flat">Sign In</button>
            </div>
          </div> -->
        </form>
      </div><!-- /.login-box-body -->
    </div><!-- /.login-box -->
    <!-- jQuery 2.1.4 -->
    <script src="<?php echo base_url('assets/plugins/jQuery/jQuery-2.1.4.min.js'); ?>"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js'); ?>"></script>
    <!-- iCheck -->
    <script>

      $(document).on('click','#btn-login',function(e){     
        $msg = $('.frm-login').find('.aj_msg');
        $msg.html('');
        $err_lbl= $('.frm-login').find('.err_lbl');
        $err_lbl.html('');

        $('.frm-login').find('input:text').each(function(){
          $(this).val($.trim($(this).val()));
        });

        $email =$('.frm-login').find('#email').val();
        $password =$('.frm-login').find('#password').val();
        if($email ==''){
          $err_lbl.html('Please enter Mobile No. or Email ID!');
          return false;
        }                

        if($password ==''){
          $err_lbl.html('Please enter Password!');
          return false;
        }        
         
        $.ajax({
          url : "<?=site_url('login'); ?>",
          type : "GET",
          data : {email:$email,password:$password},
          success : function(res){            
            res=$.trim(res);
            if(res=='E'){
              $err_lbl.html('Invalid Username or password!');          
            }
            else{
              window.location.href=res;
            }
          }
        });
      });  
    </script>
  </body>
  </html>
