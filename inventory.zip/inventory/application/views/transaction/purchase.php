<section class="content-header">
  <h1 class="top-breadcrumb">&nbsp;</h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo site_url('account/dashboard'); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
    <?php if(!empty($breadcrumbs)){ ?>
      <?php foreach($breadcrumbs as $key => $bc){ ?>
        <?php if($key == (count($breadcrumbs)-1)){ ?>
          <li class="active"><?php echo $bc['title']; ?></li>
        <?php }else{ ?>
          <li><a href="<?php echo $bc['href']; ?>"><?php echo $bc['title']; ?></a></li>
        <?php } ?>
      <?php } ?>
    <?php } ?>
    <a class="btn btn-back" href="javascript:window.history.go(-1);">Back</a>
  </ol>
</section>
<section class="content">
  <?php alert(); ?>
  <div class="row">
    <div class="col-lg-12">
      <div class="box box-success">       
        <div class="box-header with-border">
          <h3><?=$bill_type_str?></h3>
        </div>
        <form method="post" id="frm-save">
          <div class="box-body" style="overflow: auto;">          
            <div class="panel1 panel-default">
              <div class="panel-body" style="padding-top: 0px !important;padding-bottom: 0px !important;">
                <div class="col-md-2 top15">
                  <span class="badge-label">Bill No<span class="redstar">*</span></span>
                  <input class="form-control" id="bill_no" name="bill_no" value="<?=isset($purchase['bill_no'])?$purchase['bill_no']:'';?>">
                </div>
                <div class="col-lg-2 top15">
                  <div class="form-group">
                    <span class="badge-label">Bill Date<span class="redstar">*</span></span>
                    <div class="input-group temp-group" style="margin-top: 7px;">
                      <input name="bill_date" id="bill_date" style="margin-top: 0;" value="<?=isset($purchase['bill_date'])?date("d/m/Y", $purchase['bill_date']):date('d/m/Y'); ?>" type="text" class="form-control form-temp date_inp" placeholder="Bill Date" autocomplete="off">
                      <label class="input-group-addon temp-addon" for="bill_date">
                        <span class="glyphicon glyphicon-calendar"></span>
                      </label>
                    </div>
                  </div>
                </div>
                <div class="col-md-4 top15">
                  <span class="badge-label">Supplier</span>
                  <select name="supplier_id" class="select form-control" id="supplier_id">
                    <option value="0" >Select</option>
                    <?php  
                    $condition[] = array('name'=>'status','value'=>'A');
                    $order=array();
                    $order[] = array('name'=>'name','value'=>'asc');        
                    $opts = $this->setting_model->get_setting('supplier',$condition,$order);
                    if( count($opts) > 0){
                      foreach($opts as $opt){ ?>
                        <option <?=(!empty($purchase) && $purchase['supplier_id'] == $opt['supplier_id'])?'selected':''  ?> value="<?= $opt["supplier_id"] ?>" ><?= $opt["name"] ?> </option>
                      <?php } ?>
                    <?php } ?>
                  </select>
                </div>
                <div class="col-md-2 top30">
                  <span class="badge-label">Pay type<span class="redstar"></span></span>
                  <div>
                    <label style="font-weight: normal;"><input class="pay_type" type="radio" value="CA" name="pay_type" <?php echo ((!empty($purchase) && $purchase['pay_type']=='CA') || !isset($purchase['pay_type']))?'checked':''; ?> />&nbsp;Cash&nbsp;&nbsp;</label>
                    <label style="font-weight: normal;"><input class="pay_type" type="radio" value="CR" name="pay_type" <?php echo (!empty($purchase) && $purchase['pay_type']=='CR')?'checked':''; ?>/> &nbsp;Credit</label>
                  </div>
                </div>
              </div>
            </div>            
          </div>
          <div class="box-body" style="overflow: auto;">
            <table style1="width: 100%" class="table table-striped table-hover table-bordered" id="data_table">
              <thead>
                <tr>
                  <th class="th-sno">S.No.</th>
                  <th class="th-description">Product</th>
                  <th class="th-shortname">Unit</th>
                  <th class="th-shortname">Qty</th>
                  <th class="th-shortname">Price</th>
                  <th class="th-shortname">Sales Price</th>
                  <th class="th-shortname">Amount</th>
                  <th class="th-shortname">Action</th>
                </tr>
              </thead>
              <tbody>
                <?php if(!empty($purchase_dtl)){ ?>
                  <?php foreach($purchase_dtl as $key => $dtl){ $sno=$key+1; ?>
                    <tr id='tr_<?=$sno?>'>
                      <td class="center-cols sno"><?=$sno?></td>
                      <td>
                        <select class="select form-control product_id" name="prod[<?=$sno?>][product_id]">
                          <option value="0" >-</option>
                          <?php if(!empty($products)){foreach($products as $prod){ ?>
                            <option<?php if($dtl['product_id'] == $prod['product_id']){ ?> selected <?php } ?> value="<?= $prod["product_id"] ?>"><?= $prod["name"] ?></option>
                          <?php }} ?>
                        </select>
                      </td>
                      <td>
                        <select class="select form-control unit_id" name="prod[<?=$sno?>][unit_id]">
                          <option value="0" >-</option>
                          <?php if(!empty($units)){foreach($units as $unit){ ?>
                            <option<?php if($dtl['unit_id'] == $unit['unit_id']){ ?> selected <?php } ?> value="<?= $unit["unit_id"] ?>"><?= $unit["name"] ?></option>
                          <?php }} ?>
                        </select>
                      </td>
                      <td><input class="form-control calc_inp num-only qty" value="<?=$dtl['qty']; ?>" name="prod[<?=$sno?>][qty]"></td>
                      <td><input class="form-control calc_inp num-frac-only price" value="<?=$dtl['price']; ?>" name="prod[<?=$sno?>][price]"></td>
                      <td><input class="form-control calc_inp num-frac-only sal_price" value="<?=$dtl['sal_price']; ?>" name="prod[<?=$sno?>][sal_price]"></td>
                      <td><input class="form-control calc_inp amt" value="<?=$dtl['amt']; ?>" name="prod[<?=$sno?>][amt]" readonly="true"></td>
                      <td class="center-cols"><button type="button" name="delete" class="btn btn-danger" value="<?=$sno?>'" onclick="del_confirm(this)" title="Delete"><i class="fa fa-times"></i></button></td>
                    </tr>
                  <?php } ?>
                <?php } ?>
                <tr class="add-before">
                  <td></td><td></td><td></td><td></td><td></td><td></td><td></td><td class="center-cols"><button type="button" class="btn button-save btn-add" onclick="add_row();">Add Product</button></td>
                </tr>
              </tbody>
              <tfoot>
                <tr>
                  <td></td><td></td><td></td><td></td><td></td><td class="ftr-lbl">Total</td><td><input name="tot_amt" class="form-control calc_inp" id="tot_amt" value="<?= !empty($purchase)?$purchase['tot_amt']:''; ?>" readonly="true"></td><td></td>
                </tr>
                <tr>
                  <td></td><td></td><td></td><td></td><td class="ftr-lbl">Tax</td><td>
                    <select name="tax_id" id="tax_id" onchange="calc_amt()" class="select form-control">
                      <option value="0" >-</option>
                      <?php if(count($taxes) > 0){
                        foreach($taxes as $tax){ ?>
                          <option <?=(!empty($purchase) && $purchase['tax_id'] == $tax['tax_id'])?'selected':''  ?> data-val="<?= $tax["tax_percent"] ?>" value="<?= $tax["tax_id"] ?>" ><?= $tax["name"] ?> </option>
                        <?php } ?>
                      <?php } ?>  
                    </select>
                  </td><td><input name="tax_amt" class="form-control calc_inp" id="tax_amt" readonly="true" value="<?= !empty($purchase)?$purchase['tax_amt']:''; ?>"></td><td></td>
                </tr>
                <tr>
                  <td></td><td></td><td></td><td></td><td></td><td class="ftr-lbl">Nett Amount</td><td><input name="bill_amt" class="form-control calc_inp" id="bill_amt" readonly="true" value="<?= !empty($purchase)?$purchase['bill_amt']:''; ?>"></td><td></td>
                </tr>
              </tbody>             
            </table>
            <div class="col-md-12 pull-right top10 text-right top-alt" style="margin-bottom: 10px;">
              <input type="hidden" name="bill_type" value="<?= $bill_type; ?>" />
              <input type="hidden" name="purchase_id" value="<?= $purchase_id; ?>" />
              <label id="err_lbl" class="err_lbl"></label>&nbsp;&nbsp;
              <button class="btn button-save btn-save" id="btn-save" title="Save" type="button"><i class="fa fa-check" aria-hidden="true"></i> Save</button>
              <button type="reset" title="Cancel" class="btn btn-clr button-cancel"><i class="fa fa-times" aria-hidden="true"></i> Clear</button>
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>
</section>      
<script type="text/javascript"> 
  $(document).ready(function(){
    $( ".date_inp" ).datepicker({
      dateFormat: "dd-mm-yy",
    });     
    $('.select').select2();   

    $('#data_table').DataTable({
      "bPaginate": false,
      "bFilter": false,
      "bInfo": false,
      "ordering": false
    });         

    <?php if(empty($purchase)){ ?>
      add_row();
    <?php } ?>  
  }); 
  function add_row(){       
    $sno = $('#data_table tbody tr').length;
    $sno = parseInt($sno);
    
    $tr='<tr id=tr_'+$sno+'>';
    $tr +='<td class="center-cols sno">'+$sno+'</td>';
    $tr += '<td><select class="select form-control product_id" name="prod['+$sno+'][product_id]"><option value="0" >-</option><?php if(!empty($products)){foreach($products as $prod){ ?> <option value="<?= $prod["product_id"] ?>" ><?= $prod["name"] ?></option><?php }} ?></select></td>';
    $tr += '<td><select class="select form-control unit_id" name="prod['+$sno+'][unit_id]"><option value="0" >-</option><?php if(!empty($units)){foreach($units as $unit){ ?> <option value="<?= $unit["unit_id"] ?>" ><?= $unit["name"] ?></option><?php }} ?></select></td>';
    $tr +='<td><input class="form-control calc_inp num-only qty" name="prod['+$sno+'][qty]"></td>';
    $tr +='<td><input class="form-control calc_inp num-frac-only price" name="prod['+$sno+'][price]"></td>';
    $tr +='<td><input class="form-control calc_inp num-frac-only sal_price" name="prod['+$sno+'][sal_price]"></td>';
    $tr +='<td><input class="form-control calc_inp amt" name="prod['+$sno+'][amt]" readonly="true"></td>';     
    $tr += '<td class="center-cols"><button type="button" name="delete" class="btn btn-danger" value="'+$sno+'" onclick="del_confirm(this)" title="Delete"><i class="fa fa-times"></i></button></td><script>$(".select").select2();<'+'/'+'script></tr>';
    $('.add-before').before($tr);
  }   
  function del_confirm(e) {
    var id = e.value;
    $.confirm({
      icon: 'fa fa-warning',
      title: 'Confirm!',
      content: 'Do you want to Delete ?',
      type: 'red',
      buttons: {
        confirm:  {
          btnClass: 'btn-red',
          action: function(){
            $('#tr_'+id).remove();
            $sno = 1;
            $(document).find('#data_table tbody tr').each(function(){
              $(this).find('.sno').html($sno);
              $sno ++;
            });     
            calc_amt();
          }
        },
        cancel: function () { },
      }
    });
  }

  function calc_amt() {
    $tot_amt=$tax_per=$tax_amt=$bill_amt = 0;
    $(document).find('#data_table tbody tr').each(function(){
      if(!$(this).hasClass('add-before')){
        $qty= $(this).find('.qty').val();
        $price= $(this).find('.price').val();

        if($qty!=0 && $price !=0)
          $amt = parseFloat($qty)*parseFloat($price); 
        else  
          $amt=0;

        $amt = $amt.toFixed(2);
        $(this).find('.amt').val($amt);
        $tot_amt+=parseFloat($amt); 
      }     
    });   

    $('#tot_amt').val($tot_amt.toFixed(2));
    
    if($('#tax_id').val()!='0')
      $tax_per = $('#tax_id').find('option:selected').attr("data-val"); 
    else
      $tax_per=0;

    $tax_amt = $tot_amt*(parseFloat($tax_per)/100);
    $tax_amt = $tax_amt.toFixed(2);

    $('#tax_amt').val($tax_amt);

    $bill_amt=$tot_amt+parseFloat($tax_amt);    
    $('#bill_amt').val($bill_amt.toFixed(2));
  } 

  $(document).on( 'input', '.calc_inp', function() { 
    calc_amt();
  }); 
  $(document).on('click','#btn-save',function(e){      
    $err_lbl= $(this).parent().find('.err_lbl');
    $err_lbl.html('');

    $frm = $('#frm-save');        
    $val = '';
    $frm.find('input:text').each(function(){
      $(this).val($.trim($(this).val()));
    });

    if($('#bill_no').val() ==''){
      $err_lbl.html('Please enter Bill No.!');
      return false;
    }  

    if (!validate_date($("#bill_date").val())){
      $err_lbl.html('Please select valid Bill date!');
      return false;
    }

    if($('#supplier_id').val() =='0'){
      $err_lbl.html('Please select Supplier!');
      return false;
    }  

    $err=0;
    $sno=0;
    $(document).find('#data_table tbody tr').each(function(){
      if(!$(this).hasClass('add-before')){
        $sno++;
        $product_id= $(this).find('.product_id').val();
        $unit_id= $(this).find('.unit_id').val();
        
        $qty= $(this).find('.qty').val();       
        if($qty=='')
          $qty=0;
        else
          $qty=parseFloat($qty);

        $price= $(this).find('.price').val();
        if($price=='')
          $price=0;
        else
          $price=parseFloat($price);

        $sal_price= $(this).find('.sal_price').val();
        if($sal_price=='')
          $sal_price=0;
        else
          $sal_price=parseFloat($sal_price);

        $amt= $(this).find('.amt').val();
        if($amt=='')
          $amt=0;
        else
          $amt=parseFloat($amt);

        if($product_id !='0' || $unit_id !='0' || $qty!=0 || $price !=0 || $sal_price !=0 || $amt !=0){
          if($product_id =='0'){
            $err_lbl.html('Please select Product at S.No:'+$sno);
            $err=1;
            return false;
          } 
          if($unit_id =='0'){
            $err_lbl.html('Please select Unit at S.No:'+$sno);
            $err=1;
            return false;
          } 

          if($qty==0){
            $err_lbl.html('Please enter Qty at S.No:'+$sno);
            $err=1;
            return false; 
          }

          if($price==0){
            $err_lbl.html('Please enter Price at S.No:'+$sno);
            $err=1;
            return false; 
          }

          if($amt==0){
            $err_lbl.html('Invalid Amount at S.No:'+$sno);
            $err=1;
            return false; 
          }
        }
        else
          $(this).remove();
      }     
    });   

    if($err==1){
      return false; 
    }

    if($sno==0){
      $err_lbl.html('Please add Product!');
      return false; 
    }

    $bill_amt= $('#bill_amt').val();        
    if($bill_amt=='')
      $bill_amt=0;
    else
      $bill_amt=parseFloat($bill_amt);

    if($bill_amt==0){
      $err_lbl.html('Invalid Nett Amount!');
      return false; 
    }

    $('#btn-save').html('Please wait...').attr('disabled',true);
    $frm.submit();
  });  

</script>
