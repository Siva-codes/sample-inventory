  <section class="content-header pri">
  	<h1 class="top-breadcrumb">&nbsp;</h1>
  	<ol class="breadcrumb">
  		<li><a href="<?php echo site_url('account/dashboard'); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
  		<?php if(!empty($breadcrumbs)){ ?>
  			<?php foreach($breadcrumbs as $key => $bc){ ?>
  				<?php if($key == (count($breadcrumbs)-1)){ ?>
  					<li class="active"><?php echo $bc['title']; ?></li>
  				<?php }else{ ?>
  					<li><a href="<?php echo $bc['href']; ?>"><?php echo $bc['title']; ?></a></li>
  				<?php } ?>
  			<?php } ?>
  		<?php } ?>
  		<a class="btn btn-back" href="javascript:window.history.go(-1);">Back</a>
  	</ol>
  </section>
  <section class="content pri">
  	<?php alert(); ?>
  	<div class="row">
  		<div class="col-lg-12">
  			<div class="box box-success">				
  				<div class="box-header with-border">
  					<h3><?=$bill_type_str?></h3>
  				</div>
  				<form method="post" id="frm-save">
  					<div class="box-body" style="overflow: auto;">					
  						<div class="panel1 panel-default">
  							<div class="panel-body" style="padding-top: 0px !important;padding-bottom: 0px !important;">
  								<div class="col-md-2 top15">
  									<span class="badge-label">Bill No<span class="redstar">*</span></span>
  									<input class="form-control" id="bill_no" name="bill_no" value="<?=isset($sales['bill_no'])?$sales['bill_no']:'';?>">
  								</div>
  								<div class="col-lg-2 top15">
  									<div class="form-group">
  										<span class="badge-label">Bill Date<span class="redstar">*</span></span>
  										<div class="input-group temp-group" style="margin-top: 7px;">
  											<input name="bill_date" id="bill_date" style="margin-top: 0;" value="<?=isset($sales['bill_date'])?date("d/m/Y", $sales['bill_date']):date('d/m/Y'); ?>" type="text" class="form-control form-temp date_inp" placeholder="Bill Date" autocomplete="off">
  											<label class="input-group-addon temp-addon" for="bill_date">
  												<span class="glyphicon glyphicon-calendar"></span>
  											</label>
  										</div>
  									</div>
  								</div>
  								<div class="col-md-4 top15">
  									<span class="badge-label">Customer</span>
  									<select name="customer_id" class="select form-control" id="customer_id">
  										<option value="0" >Select</option>
  										<?php  
  										$condition[] = array('name'=>'status','value'=>'A');
  										$order=array();
  										$order[] = array('name'=>'name','value'=>'asc');        
  										$opts = $this->setting_model->get_setting('customer',$condition,$order);
  										if( count($opts) > 0){
  											foreach($opts as $opt){ ?>
  												<option  <?=(!empty($sales) && $sales['customer_id'] == $opt['customer_id'])?'selected':''  ?> value="<?= $opt["customer_id"] ?>" ><?= $opt["name"] ?> </option>
  											<?php } ?>
  										<?php } ?>
  									</select>
  								</div>
  								<div class="col-md-2 top30">
  									<span class="badge-label">Pay type<span class="redstar"></span></span>
  									<div>
  										<label style="font-weight: normal;"><input class="pay_type" type="radio" value="CA" name="pay_type" <?php echo ((!empty($sales) && $sales['pay_type']=='CA') || !isset($sales['pay_type']))?'checked':''; ?> />&nbsp;Cash&nbsp;&nbsp;</label>
  										<label style="font-weight: normal;"><input class="pay_type" type="radio" value="CR" name="pay_type" <?php echo (!empty($sales) && $sales['pay_type']=='CR')?'checked':''; ?>/> &nbsp;Credit</label>
  									</div>
  								</div>
  							</div>
  						</div>						
  					</div>
  					<div class="box-body" style="overflow: auto;">
  						<table style1="width: 100%" class="table table-striped table-hover table-bordered" id="data_table">
  							<thead>
  								<tr>
  									<th class="th-sno">S.No.</th>
  									<th class="th-description">Product</th>									
  									<th class="th-name">Purchase Price</th>
  									<th class="th-shortname">Unit</th>
  									<th class="th-shortname">Qty</th>
  									<th class="th-shortname">Price</th>									
  									<th class="th-shortname">Amount</th>
  									<th class="th-shortname">Action</th>
  								</tr>
  							</thead>
  							<tbody>
  								<?php if(!empty($sales_dtl)){ ?>
  									<?php foreach($sales_dtl as $key => $dtl){ $sno=$key+1; ?>
  										<tr id='tr_<?=$sno?>'>
  											<td class="center-cols sno"><?=$sno?></td>
  											<td>
  												<select class="select form-control product_id" name="prod[<?=$sno?>][product_id]">
  													<option value="0" >-</option>
  													<?php if(!empty($products)){foreach($products as $prod){ ?>
  														<option<?php if($dtl['product_id'] == $prod['product_id']){ ?> selected <?php } ?> value="<?= $prod["product_id"] ?>"><?= $prod["name"] ?></option>
  													<?php }} ?>
  												</select>
  											</td>
  											<td>
  												<select class="select form-control pur_price" name="prod[<?=$sno?>][pur_price]">
  													<option value="0" >-</option>
  													<?php $condition=$order=$join=array();
  													$select=array('purchase_dtl.price','purchase_dtl.sal_price','purchase_dtl.unit_id','unit.name as unit_name');													
  													$condition[] = array('name'=>'product_id','value'=>$dtl['product_id']);
  													$order[] = array('name'=>'purchase_dtl_id','value'=>'asc');        
  													$join[] = array('table_name' => 'unit' ,'condition' => 'unit.unit_id =purchase_dtl.unit_id' ,'join_type' => 'left'); 
  													$res = $this->setting_model->get_setting('purchase_dtl',$condition,$order,false,$select,$join);

  													if(!empty($res)){foreach($res as $res1){ ?>
  														<option <?php if($dtl['pur_unit_id'] == $res1['unit_id'] && $dtl['pur_price'] == $res1["price"]){ ?> selected <?php } ?> data-unit-id="<?=$res1["unit_id"]?>" data-sal-price="<?=$res1["sal_price"]?>" value="<?=$res1["price"].'/'.$res1["unit_id"]?>">₹<?=number_format($res1["price"], 2).' / '.$res1["unit_name"].' (Sal. ₹'.number_format($res1["sal_price"], 2).')';?></option>
  													<?php }} ?>
  												</select>
  											</td>
  											<td>
  												<select class="select form-control unit_id" name="prod[<?=$sno?>][unit_id]">
  													<option value="0" >-</option>
  													<?php if(!empty($units)){foreach($units as $unit){ ?>
  														<option<?php if($dtl['unit_id'] == $unit['unit_id']){ ?> selected <?php } ?> value="<?= $unit["unit_id"] ?>"><?= $unit["name"] ?></option>
  													<?php }} ?>
  												</select>
  											</td>
  											<td><input class="form-control calc_inp num-only qty" value="<?=$dtl['qty']; ?>" name="prod[<?=$sno?>][qty]"></td>
  											<td><input class="form-control calc_inp num-frac-only price" value="<?=$dtl['price']; ?>" name="prod[<?=$sno?>][price]"></td>
  											<td><input class="form-control calc_inp amt" value="<?=$dtl['amt']; ?>" name="prod[<?=$sno?>][amt]" readonly="true"></td>
  											<td class="center-cols"><button type="button" name="delete" class="btn btn-danger" value="<?=$sno?>'" onclick="del_confirm(this)" title="Delete"><i class="fa fa-times"></i></button></td>
  										</tr>
  									<?php } ?>
  								<?php } ?>
  								<tr class="add-before">
  									<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td class="center-cols"><button type="button" class="btn button-save btn-add" onclick="add_row();">Add Product</button></td>
  								</tr>
  							</tbody>
  							<tfoot>
  								<tr>
  									<td></td><td></td><td></td><td></td><td></td><td class="ftr-lbl">Total</td><td><input name="tot_amt" class="form-control calc_inp" id="tot_amt" value="<?= !empty($sales)?$sales['tot_amt']:''; ?>" readonly="true"></td><td></td>
  								</tr>
  								<tr>
  									<td></td><td></td><td></td><td></td><td class="ftr-lbl">Tax</td><td>
  										<select name="tax_id" id="tax_id" onchange="calc_amt()" class="select form-control">
  											<option value="0" >-</option>
  											<?php if(count($taxes) > 0){
  												foreach($taxes as $tax){ ?>
  													<option <?=(!empty($sales) && $sales['tax_id'] == $tax['tax_id'])?'selected':''  ?> data-val="<?= $tax["tax_percent"] ?>" value="<?= $tax["tax_id"] ?>" ><?= $tax["name"] ?> </option>
  												<?php } ?>
  											<?php } ?>	
  										</select>
  									</td><td><input name="tax_amt" class="form-control calc_inp" id="tax_amt" readonly="true" value="<?= !empty($sales)?$sales['tax_amt']:''; ?>"></td><td></td>
  								</tr>
  								<tr>
  									<td></td><td></td><td></td><td></td><td></td><td class="ftr-lbl">Nett Amount</td><td><input name="bill_amt" class="form-control calc_inp" id="bill_amt" readonly="true" value="<?= !empty($sales)?$sales['bill_amt']:''; ?>"></td><td></td>
  								</tr>
  							</tbody> 						 
  						</table>
  						<div class="col-md-12 pull-right top10 text-right top-alt" style="margin-bottom: 10px;">
  							<?php if(!empty($sales_id)) { ?>
  								<button style="float: left;" class="btn button-save btn-save" id="btn-print" title="Print" type="button"><i class="fa fa-print" aria-hidden="true"></i> Print</button>
  							<?php } ?>
  							<input type="hidden" id="bill_type" name="bill_type" value="<?= $bill_type; ?>" />
  							<input type="hidden" id="sales_id" name="sales_id" value="<?= $sales_id; ?>" />
                <input type="hidden" id="print_bill" name="print_bill" value="0" />
                <label id="err_lbl" class="err_lbl"></label>&nbsp;&nbsp;
                <button class="btn button-save btn-save" id="btn-save" title="Save" type="button"><i class="fa fa-check" aria-hidden="true"></i> Save</button>
                <button type="reset" title="Cancel" class="btn btn-clr button-cancel"><i class="fa fa-times" aria-hidden="true"></i> Clear</button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </section>    
  <section class="content bill_cont" style="display: none;">
  </section>  
  <script type="text/javascript">	
  	$(document).ready(function(){
  		$( ".date_inp" ).datepicker({
  			dateFormat: "dd-mm-yy",
  		}); 		
  		$('.select').select2();		

  		$('#data_table').DataTable({
  			"bPaginate": false,
  			"bFilter": false,
  			"bInfo": false,
  			"ordering": false
  		});     		

  		<?php if(empty($sales)){ ?>
  			add_row();
  		<?php } ?>	
  	}); 
  	$(document).on('change','.product_id',function(){
  		$tis = $(this);
  		$product_id = $tis.val();

  		if ($product_id !='0'){
  			$.ajax({
  				url : '<?php echo site_url('transaction/get_pur_prices'); ?>/'+$product_id,
  				success : function(res){					
  					$tis.parent().parent().find('.pur_price').html(res);
  				}
  			});
  		}
  		else{
  			$tis.parent().parent().find('.pur_price').html('<option value="0">-</option>');
  		}
  	});
  	$(document).on('change','.pur_price',function(){
  		if($(this).val()!='0'){
  			$unit_id=$(this).find(':selected').attr('data-unit-id');
  			$sal_price=$(this).find(':selected').attr('data-sal-price');	
  			$(this).parent().parent().find('.unit_id').val($unit_id).select2().trigger('change');
  			$(this).parent().parent().find('.price').val($sal_price);
  			calc_amt();
  		}		
  	});
  	function add_row(){				
  		$sno = $('#data_table tbody tr').length;
  		$sno = parseInt($sno);
  		
  		$tr='<tr id=tr_'+$sno+'>';
  		$tr +='<td class="center-cols sno">'+$sno+'</td>';
  		$tr += '<td><select class="select form-control product_id" name="prod['+$sno+'][product_id]"><option value="0" >-</option><?php if( count($products) > 0){foreach($products as $prod){ ?>	<option value="<?= $prod["product_id"] ?>" ><?= $prod["name"] ?></option><?php }} ?></select></td>';		
  		$tr += '<td><select class="select form-control pur_price" name="prod['+$sno+'][pur_price]"><option value="0">-</option></select></td>';
  		$tr += '<td><select class="select form-control unit_id" name="prod['+$sno+'][unit_id]"><option value="0" >-</option><?php if( count($units) > 0){foreach($units as $unit){ ?>	<option value="<?= $unit["unit_id"] ?>" ><?= $unit["name"] ?></option><?php }} ?></select></td>';
  		$tr +='<td><input class="form-control calc_inp num-only qty" name="prod['+$sno+'][qty]"></td>';
  		$tr +='<td><input class="form-control calc_inp num-frac-only price" name="prod['+$sno+'][price]"></td>';		
  		$tr +='<td><input class="form-control calc_inp amt" name="prod['+$sno+'][amt]" readonly="true"></td>';		 
  		$tr += '<td class="center-cols"><button type="button" name="delete" class="btn btn-danger" value="'+$sno+'" onclick="del_confirm(this)" title="Delete"><i class="fa fa-times"></i></button></td><script>$(".select").select2();<'+'/'+'script></tr>';
  		$('.add-before').before($tr);
  	}		
  	function del_confirm(e) {
  		var id = e.value;
  		$.confirm({
  			icon: 'fa fa-warning',
  			title: 'Confirm!',
  			content: 'Do you want to Delete ?',
  			type: 'red',
  			buttons: {
  				confirm:  {
  					btnClass: 'btn-red',
  					action: function(){
  						$('#tr_'+id).remove();
  						$sno = 1;
  						$(document).find('#data_table tbody tr').each(function(){
  							$(this).find('.sno').html($sno);
  							$sno ++;
  						});			
  						calc_amt();
  					}
  				},
  				cancel: function () { },
  			}
  		});
  	}

  	function calc_amt() {
  		$tot_amt=$tax_per=$tax_amt=$bill_amt = 0;
  		$(document).find('#data_table tbody tr').each(function(){
  			if(!$(this).hasClass('add-before')){
  				$qty= $(this).find('.qty').val();
  				$price= $(this).find('.price').val();

  				if($qty!=0 && $price !=0)
  					$amt = parseFloat($qty)*parseFloat($price);	
  				else	
  					$amt=0;

  				$amt = $amt.toFixed(2);
  				$(this).find('.amt').val($amt);
  				$tot_amt+=parseFloat($amt);	
  			}			
  		});		

  		$('#tot_amt').val($tot_amt.toFixed(2));
  		
  		if($('#tax_id').val()!='0')
  			$tax_per = $('#tax_id').find('option:selected').attr("data-val"); 
  		else
  			$tax_per=0;

  		$tax_amt = $tot_amt*(parseFloat($tax_per)/100);
  		$tax_amt = $tax_amt.toFixed(2);

  		$('#tax_amt').val($tax_amt);

  		$bill_amt=$tot_amt+parseFloat($tax_amt);		
  		$('#bill_amt').val($bill_amt.toFixed(2));
  	} 

  	$(document).on( 'input', '.calc_inp', function() { 
  		calc_amt();
  	});
  	$(document).on('click','#btn-print',function(e){      
  		$.ajax({
        url : '<?php echo site_url('transaction/print_bill'); ?>/'+$('#bill_type').val()+'/'+$('#sales_id').val(),
        success : function(res){          
          $('.bill_cont').html(res);
          window.print();
        }
      });
  	});	
   
    $(document).on('click','#btn-save',function(e){      
      $err_lbl= $(this).parent().find('.err_lbl');
      $err_lbl.html('');

      $frm = $('#frm-save');        
      $val = '';
      $frm.find('input:text').each(function(){
       $(this).val($.trim($(this).val()));
     });

      if($('#bill_no').val() ==''){
       $err_lbl.html('Please enter Bill No.!');
       return false;
     }  

     if (!validate_date($("#bill_date").val())){
       $err_lbl.html('Please select valid Bill date!');
       return false;
     }

     if($('#customer_id').val() =='0'){
       $err_lbl.html('Please select Customer!');
       return false;
     }  

     $err=0;
     $sno=0;
     $(document).find('#data_table tbody tr').each(function(){
       if(!$(this).hasClass('add-before')){
        $sno++;
        $product_id= $(this).find('.product_id').val();
        $unit_id= $(this).find('.unit_id').val();

        $qty= $(this).find('.qty').val();				
        if($qty=='')
         $qty=0;
       else
         $qty=parseFloat($qty);

       $price= $(this).find('.price').val();
       if($price=='')
         $price=0;
       else
         $price=parseFloat($price);

       $sal_price= $(this).find('.sal_price').val();
       if($sal_price=='')
         $sal_price=0;
       else
         $sal_price=parseFloat($sal_price);

       $amt= $(this).find('.amt').val();
       if($amt=='')
         $amt=0;
       else
         $amt=parseFloat($amt);

       if($product_id !='0' || $unit_id !='0' || $qty!=0 || $price !=0 || $sal_price !=0 || $amt !=0){
         if($product_id =='0'){
          $err_lbl.html('Please select Product at S.No:'+$sno);
          $err=1;
          return false;
        } 
        if($unit_id =='0'){
          $err_lbl.html('Please select Unit at S.No:'+$sno);
          $err=1;
          return false;
        } 

        if($qty==0){
          $err_lbl.html('Please enter Qty at S.No:'+$sno);
          $err=1;
          return false;	
        }

        if($price==0){
          $err_lbl.html('Please enter Price at S.No:'+$sno);
          $err=1;
          return false;	
        }

        if($amt==0){
          $err_lbl.html('Invalid Amount at S.No:'+$sno);
          $err=1;
          return false;	
        }
      }
      else
       $(this).remove();
   }			
 });		

     if($err==1){
       return false;	
     }

     if($sno==0){
       $err_lbl.html('Please add Product!');
       return false;	
     }

     $bill_amt= $('#bill_amt').val();				
     if($bill_amt=='')
       $bill_amt=0;
     else
       $bill_amt=parseFloat($bill_amt);

     if($bill_amt==0){
       $err_lbl.html('Invalid Nett Amount!');
       return false;	
     }

     $('#btn-save').html('Please wait...').attr('disabled',true);

     $.confirm({
      icon: 'fa fa-warning',
      title: 'Print Bill',
      content: 'Print Bill?',
      type: 'orange',
      buttons: {
        Okay: {
          btnClass: 'btn-orange',
          action: function(){
           $('#print_bill').val('1');             
           var url = $frm.attr('action');

           $.ajax({
             type: "POST",
             url: url,
             data: $frm.serialize(), 
             success: function(res)
             {
               $('.bill_cont').html(res);
               window.print();
               window.location.href="<?=site_url('sales')?>";
             }
           });
         }
       },
       Cancel: function () {
        $('#print_bill').val('0');           
        $frm.submit();
      },
    }
  });		
   });  

 </script>
