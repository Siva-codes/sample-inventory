    <style type="text/css" media="print">
      @page 
      {
        size: auto;   /* auto is the current printer page size */
        margin: 0mm;  /* this affects the margin in the printer settings */
      }
      body 
      {
        background-color:#FFFFFF; 
        margin: 0px;  /* the margin on the content before printing */
      }
      p{font-family:arial;}
      .pri{display:none;}  
      .bill_cont{display: block !important;}  
    </style>   
    <div class1="grey-box register-blk" id="data-cont" style="margin-bottom: 10px;"><!-- greay box -->
     <div class="row">
      <div class="col-lg-12">
        <div class="box1">               
          <div class="box-header1 text-center">
            <h2><?=$company['name']?></h2>
            <h3><?=nl2br($company['address'])?></h3>
          </div>
          <hr>
          <div class="box-body" style="overflow: auto;">                  
            <div class="panel1 panel-default">
              <div class="panel-body" style="padding-top: 0px !important;padding-bottom: 0px !important;">
                <div class="row">
                  <div class="col-md-6" style="display: inline-block;vertical-align: top;">
                    <b>Bill No</b>
                    <?=$sales['bill_no'];?><br>
                    <b>Bill Date</b>
                    <?=date("d/m/Y", $sales['bill_date']);?><br>
                    <b>Pay type</b>
                    <?=$sales['pay_type']=='CA'?'Cash':'Credit';?>
                  </div>                                
                  <div class="col-md-6" style="display: inline-block;vertical-align: top;">
                    <b>Customer</b>
                    <?=$sales['customer_name'];?><br>
                    <?php if(!empty($sales['customer_address'])) { ?>
                      <?=nl2br($sales['customer_address']);?><br>
                    <?php } ?>                     
                  </div>
                </div>
              </div>
            </div>                      
          </div>
          <div class="box-body" style="overflow: auto;">
            <table style1="width: 100%" class="table table-striped table-hover table-bordered" id="data_table">
              <thead>
                <tr>
                  <th style="width: 5%">S.No.</th>
                  <th style="width: 30%">Product</th>                                 
                  <th style="width: 20%">Unit</th>
                  <th style="width: 10%">Qty</th>
                  <th style="width: 10%;text-align: right;">Price</th>                                 
                  <th style="width: 10%;text-align: right;">Amount</th>
                </tr>
              </thead>
              <tbody>
                <?php if(!empty($sales_dtl)){ ?>
                  <?php foreach($sales_dtl as $key => $dtl){ $sno=$key+1; ?>
                    <tr id='tr_<?=$sno?>'>
                      <td class="center-cols sno"><?=$sno?></td>
                      <td><?= $dtl["product_name"] ?></td>
                      <td><?= $dtl["unit_name"] ?></td>
                      <td><?= $dtl["qty"] ?></td>
                      <td style="text-align: right;"><?= number_format($dtl["price"],2) ?></td>
                      <td style="text-align: right;"><?= number_format($dtl["amt"],2) ?></td>
                    </tr>
                  <?php } ?>
                <?php } ?>
              </tbody>
              <tfoot>
                <tr>
                  <td colspan="4"></td><td style="font-weight: bold;text-align: right;">Total</td><td style="text-align: right;"><?= number_format($sales["tot_amt"],2) ?></td>
                </tr>
                <tr>
                  <td colspan="3"></td><td style="font-weight: bold;text-align: right;">Tax</td><td style="text-align: right;"><?= $sales["tax_name"] ?></td><td style="text-align: right;"><?= number_format($sales["tax_amt"],2) ?></td>
                </tr>
                <tr>
                  <td colspan="4"></td><td style="font-weight: bold;text-align: right;vertical-align: middle;">Nett&nbsp;Amount</td><td style="text-align: right;font-size: 23px;"><?= number_format($sales["bill_amt"],2) ?></td>
                </tr>
              </tbody>                         
            </table>                        
          </div>
        </div>        
      </div>
    </div>
  </div>