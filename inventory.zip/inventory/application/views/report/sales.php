 <!----------------datatables---------->
 <link href='<?=base_url("assets/plugins/datatables-plugins/dataTables.bootstrap.css")?>' rel="stylesheet">
 <!-- DataTables Responsive CSS -->
 <link href='<?=base_url("assets/plugins/datatables-responsive/dataTables.responsive.css")?>' rel="stylesheet">
 <script type="text/javascript" src='<?=base_url("assets/tableExport/tableExport.js")?>'></script>
 <script type="text/javascript" src='<?=base_url("assets/tableExport/jquery.base64.js")?>'></script>
 <script type="text/javascript" src='<?=base_url("assets/tableExport/html2canvas.js")?>'></script>
 <script type="text/javascript" src='<?=base_url("assets/tableExport/jspdf/libs/sprintf.js")?>'></script>
 <script type="text/javascript" src='<?=base_url("assets/tableExport/jspdf/jspdf.js")?>'></script>
 <script type="text/javascript" src='<?=base_url("assets/tableExport/jspdf/libs/base64.js")?>'></script>

 <script type="text/javascript" src='<?=base_url("assets/tableExport/jspdf/libs/sprintf.js")?>'></script>
 <script type="text/javascript" src='<?=base_url("assets/tableExport/jspdf/jspdf.js")?>'></script>
 <script type="text/javascript" src='<?=base_url("assets/tableExport/jspdf/libs/base64.js")?>'></script>

 <link rel="stylesheet" href="https://cdn.datatables.net/1.10.18/css/dataTables.bootstrap.min.css">
 <link rel="stylesheet" href="https://cdn.datatables.net/fixedheader/3.1.4/css/fixedHeader.bootstrap.min.css">

 <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.2/css/responsive.bootstrap.min.css">

 <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>

 <script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap4.min.js"></script>
 <script src="https://cdn.datatables.net/rowreorder/1.2.7/js/dataTables.rowReorder.min.js"></script>

 <!----------------jquery alert plugin---------->
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.css">
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.js"></script>
 <style type="text/css">
 	@media (min-width: 768px){
 		.modal-dialog {
 			width: 1000px;
 			margin: 30px auto;
 		}
 	}
 </style>
 <section class="content-header">
 	<h1 class="top-breadcrumb">&nbsp;</h1>
 	<ol class="breadcrumb">
 		<li><a href="<?php echo site_url('account/dashboard'); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
 		<?php if(!empty($breadcrumbs)){ ?>
 			<?php foreach($breadcrumbs as $key => $bc){ ?>
 				<?php if($key == (count($breadcrumbs)-1)){ ?>
 					<li class="active"><?php echo $bc['title']; ?></li>
 				<?php }else{ ?>
 					<li><a href="<?php echo $bc['href']; ?>"><?php echo $bc['title']; ?></a></li>
 				<?php } ?>
 			<?php } ?>
 		<?php } ?>
 		<a class="btn btn-success btn-back" href="javascript:window.history.go(-1);">Back</a>
 	</ol>
 </section> 
 <section class="content">
 	<?php alert(); ?>
 	<div class="row">
 		<div class="col-lg-12">
 			<div class="box box-success">
 				<div class="box-header with-border">
 					<h3><?php echo $page_title; ?>
 					<a class="btn pull-right btn-add btn-success" href="<?=site_url('sales');?>">Add Sales</a></h3>
 				</div>
 				<div class="box-body" style="overflow: auto;">
 					<?php if(!empty($recs)){ ?>
 						<table style1="width: 100%" class="table table-striped table-hover table-bordered" id="data_table">
 							<thead>
 								<tr>
 									<th class="th-sno">SNo.</th>
 									<?php foreach ($data_hdrs as $key => $hdr) { ?>	
 										<th class="<?php echo 'th-'.$tbl_hdr_widths[$key];?>"><?php echo $hdr?></th>
 									<?php }?>		
 								</tr>
 							</thead>
 							<tbody>
 								<?php
 								if( count($recs) > 0){
 									foreach($recs as $key => $rec){ 
 										$id = $rec["sales_id"]; 				
 										if($bill_type=='B')
 											$url = site_url('edit-sales/'.$id);
 										else
 											$url = site_url('edit-sales-return/'.$id);						
 										?>
 										<tr class="odd gradeX">
 											<td style="text-align:center"><?=$key+1?></td>
 											<?php foreach ($data_cols as $col) { 
 												if($col =='action')
 													$col_styl = ' style="text-align:center"';
 												elseif(strpos($col,'_amt'))
 													$col_styl = ' style="text-align:right"';
 												else
 													$col_styl='';
 												?>	

 												<td<?=$col_styl?>><?php 
 												$col_val = '';
 												if($col =='sno')
 													$col_val = $sno;
 												elseif($col =='pay_type'){
 													if($rec[$col]=='CA')
 														$col_val = 'Cash';
 													else
 														$col_val = 'Credit';
 												}
 												elseif(strpos($col,'_date'))
 													$col_val = !empty($rec[$col])?date("d-m-Y", $rec[$col]):'';
 												elseif(strpos($col,'_amt'))
 													$col_val = number_format($rec[$col],2);
 												elseif($col =='action'){
 													$col_val = '<a class="btn_edit btn btn-primary" href="'.$url.'"><i class="fa fa-pencil" title="Edit"></i></a> 													
 													<button type="button" id="delete" onclick="del_confirm(this)" name="delete" value="'.$id.'" class="btn btn-danger" title="Delete"><i class="fa fa-times"></i></button>';
 												} 											
 												else	
 													$col_val = $rec[$col];

 												echo $col_val;
 												?></td>
 											<?php }?>
 										</tr>
 									<?php  }
 								} ?>          
 							</tbody> 						 
 						</table>
 					<?php }else{ ?>
 						<div class="alert alert-info">No <?=$bill_type_str?> added.</div>
 					<?php } ?>
 				</div>
 			</div>
 		</div>
 	</div>
 </section>  
 <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
 <script src='<?=base_url("https://code.jquery.com/ui/1.12.1/jquery-ui.js")?>'></script>
 <script>
 	$(document).ready(function() {
 		var $tot_cols = parseInt('<?= count($data_cols); ?>');
 		$('#data_table').DataTable({
 			"scrollX": true,
 			"columnDefs": [
 			{ "orderable": false, "targets": [$tot_cols]},
 			{ "orderable": true, "targets": [0, 1]}
 			],
 			"aaSorting": []
 		});    
 	}); 	
 	
 	function del_confirm(e) {
 		var id = e.value;
 		$.confirm({
 			icon: 'fa fa-warning',
 			title: 'Confirm!',
 			content: 'Do you want to Delete ?',
 			type: 'red',
 			buttons: {
 				confirm:  {
 					btnClass: 'btn-red',
 					action: function(){
 						$.confirm({
 							icon: 'fa fa-warning',
 							title: 'Confirm!',
 							content: 'If you Delete, You cant restore this record !',
 							type: 'red',
 							buttons: {
 								Okay: {
 									btnClass: 'btn-red',
 									action: function(){
 										$.ajax({
 											url : "<?= site_url('aj_data') ?>",
 											data: 'action=del_setting&type=sales&type_str=<?=$bill_type_str?>&id='+id,
 											success: function (res) {
 												if(res == 'S'){
 													window.location.reload();
 												}
 												else{
 													$.alert(res);
 												}
 											}
 										});
 									}
 								},
 								Cancel: function () { },
 							}
 						});
 					}
 				},
 				cancel: function () { },
 			}
 		});
 	}   
 </script>
