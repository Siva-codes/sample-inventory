 <section class="content-header">
 	<h1 class="top-breadcrumb">&nbsp;</h1>
 	<ol class="breadcrumb">
 		<li><a href="<?php echo site_url('account/dashboard'); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
 		<?php if(!empty($breadcrumbs)){ ?>
 			<?php foreach($breadcrumbs as $key => $bc){ ?>
 				<?php if($key == (count($breadcrumbs)-1)){ ?>
 					<li class="active"><?php echo $bc['title']; ?></li>
 				<?php }else{ ?>
 					<li><a href="<?php echo $bc['href']; ?>"><?php echo $bc['title']; ?></a></li>
 				<?php } ?>
 			<?php } ?>
 		<?php } ?>
 		<a class="btn btn-back" href="javascript:window.history.go(-1);">Back</a>
 	</ol>
 </section>

 <section class="content">
 	<?php alert(); ?>
 	<div class="row">
 		<div class="col-lg-12">
 			<div class="box box-success">
 				<div class="box-header with-border">
 					<h3><?php echo $page_title; ?>
 					<button type="button" id="btn_add" class="btn pull-right btn-add" ><i id="clk-angle" class="fa fa-angle-down" aria-hidden="true"></i>&nbsp;&nbsp;Add&nbsp;<?php echo ucfirst($setting_type_str);?></button></h3>
 				</div>
 				<?php require 'application/views/setting/setting_add.php'; ?> 				
 				<div class="box-body" style="overflow: auto;">
 					<?php if(!empty($recs)){ ?>
 						<table style1="width: 100%" class="table table-striped table-hover table-bordered" id="data_table">
 							<thead>
 								<tr>
 									<th class="th-sno">SNo.</th>
 									<?php foreach ($data_hdrs as $key => $hdr) { ?>	
 										<th class="<?php echo 'th-'.$tbl_hdr_widths[$key];?>"><?php echo $hdr?></th>
 									<?php }?>		
 								</tr>
 							</thead>
 							<tbody>
 								<?php
 								if( count($recs) > 0){
 									foreach($recs as $key => $rec){ 
 										$id = $rec[$tbl_name."_id"];
 										?>
 										<tr class="odd gradeX">
 											<td style="text-align:center"><?=$key+1?></td>
 											<?php foreach ($data_cols as $col) { 
 												if($col =='status' || $col =='action')
 													$col_styl = ' style="text-align:center"';
 												else
 													$col_styl='';
 												?>	

 												<td<?=$col_styl?>><?php 
 												$col_val = '';
 												if($col =='sno')
 													$col_val = $sno;
 												elseif($col =='status')
 													$col_val = $rec['status']=='A'?'<i class="fa fa-check text-success"></i>':'<i class="fa fa-times text-red"></i>'; 
 												elseif($col =='action'){
 													$col_val = '<button class="btn_edit btn btn-primary" data-toggle="modal" data-target="#mod_data" name="edit" value="'.$id.'" data-id="'.$id.'"><i class="fa fa-pencil" title="Edit"></i></button>
 													<button type="button" onclick="del_confirm(this)" name="delete" value="'.$id.'" class="btn btn-danger" title="Delete"><i class="fa fa-times"></i></button>';
 												} 											
 												else	
 													$col_val = $rec[$col];

 												echo $col_val;
 												?></td>
 											<?php }?>
 										</tr>
 									<?php  }
 								} ?>          
 							</tbody> 						 
 						</table>
 					<?php }else{ ?>
 						<div class="alert alert-info">No <?php echo ucfirst($setting_type_str);?> added.</div>
 					<?php } ?>
 				</div>
 			</div>
 		</div>
 	</div>
 </section> 
 <div class="modal fade" id="mod_data" role="dialog">
 	<div class="modal-dialog cascading-modal" role="document">
 		<!--Content-->
 		<div class="modal-content">
 			<!--Header-->
 			<div class="modal-header light-blue darken-3 white-text">
 				<button type="button" class="close waves-effect waves-light" data-dismiss="modal" aria-label="Close">
 					<span aria-hidden="true">×</span>
 				</button>
 				<h4 class="title"><i class="fa fa-pencil-alt"></i> Edit <?php echo ucfirst($setting_type_str);?></h4>
 			</div>
 			<!--Body-->
 			<div class="modal-body mb-0">
 				<form method="post" class="frm-upd" enctype="multipart/form-data">
 					<div id="upd"></div>
 					<br/>
 					<div class="text-center">
 						<label class="err_lbl"></label><br>
 						<button type="button" name="update" id="btn_upd" data-id="0" class=" btn btn-success button-update btn-save"><i class="fa fa-check" aria-hidden="true"></i>&nbsp;&nbsp;Update
 						</button>
 						<button type="button" data-dismiss="modal" class="btn btn-warning btn-clr"><i class="fa fa-times"></i>&nbsp;&nbsp;Cancel</button>
 					</div>
 					<br/>
 				</form>
 			</div>
 		</div>
 		<!--/.Content-->
 	</div>
 </div>
 <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
 <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
 <script>
 	$(document).ready(function() {
 		$('.select').select2();
 		var $tot_cols = parseInt('<?= count($data_cols); ?>');
 		$("#btn_add").click(function(){
 			$("#entry-content").toggle();
 			$('#clk-angle').toggleClass('fa-angle-up').toggleClass('fa-angle-down');
 		});
 		$('#data_table').DataTable({
 			"scrollX": true,
 			"columnDefs": [
 			{ "orderable": false, "targets": [$tot_cols]},
 			{ "orderable": true, "targets": [0, 1]}
 			],
 			"aaSorting": []
 		});    
 	});
 	$( ".btn_edit" ).click(function( event ) {
 		event.preventDefault();
 		var id =$(this).attr('data-id');
 		$edit_txt = "<?=$tbl_name.'_edit'; ?>";
 		$.ajax({
 			url : "<?= site_url('aj_data') ?>",
 			data: 'action='+$edit_txt+'&id='+id,
 			dataType: 'html'
 		})
 		.done(function(data){      
 			$('#upd').empty().append(data);
 			$('#btn_upd').attr('data-id',id);
 		})
 		$('#mod_data').find('.err_lbl').html('');
 		$('#mod_data').modal('show');
 		return false;
 	});

 	function del_confirm(e) {
 		var id = e.value;
 		$.confirm({
 			icon: 'fa fa-warning',
 			title: 'Confirm!',
 			content: 'Do you want to Delete ?',
 			type: 'red',
 			buttons: {
 				confirm:  {
 					btnClass: 'btn-red',
 					action: function(){
 						$.confirm({
 							icon: 'fa fa-warning',
 							title: 'Confirm!',
 							content: 'If you Delete, You cant restore this record !',
 							type: 'red',
 							buttons: {
 								Okay: {
 									btnClass: 'btn-red',
 									action: function(){
 										$.ajax({
 											url : "<?= site_url('aj_data') ?>",
 											data: 'action=del_setting&type=<?=$tbl_name;?>&type_str=<?=$setting_type_str;?>&id='+id,
 											success: function (res) {
 												if(res == 'S'){
 													window.location.reload();
 												}
 												else{
 													$.alert(res);
 												}
 											}
 										});
 									}
 								},
 								Cancel: function () { },
 							}
 						});
 					}
 				},
 				cancel: function () { },
 			}
 		});
 	}  

 	$(document).on('click','.btn-save',function(e){      
 		$err_lbl= $(this).parent().find('.err_lbl');
 		$err_lbl.html('');

 		if($(this).attr('data-id')){
 			$id=$(this).attr('data-id');
 			$frm = $('.frm-upd');
 		}
 		else{
 			$id =0;
 			$frm = $('.frm-save');        
 		}

 		$val = '';
 		$frm.find('input:text').each(function(){
 			$(this).val($.trim($(this).val()));
 		});

 		$val=$frm.find('.name').val();

 		if($val ==''){
 			$err_lbl.html('Please enter name!');
 			return false;
 		}      

 		$chk_val=$val;   
 		$chk_type = '<?=$tbl_name; ?>';
 		$setting_type_str = '<?=$setting_type_str; ?>';

 		if($chk_type=='unit'){
 			$parent_unit_id=$frm.find('.parent_unit_id').val();
 			$conv=$frm.find('.conversion').val(); 			

 			if($parent_unit_id!=0){
 				if($conv==''){
 					$err_lbl.html('Please enter conversion!');
 					return false;
 				} 				
 			}
 			else{
 				if($conv!==''){
 					$err_lbl.html('invalid conversion!');
 					return false;
 				} 				
 			}
 		}
 		
 		if($chk_type=='product'){
 			if($frm.find('.product_category_id').val()==0){
 				$err_lbl.html('Please select Category!');
 				return false;
 			}

 			// if($frm.find('.unit_id').val()==0){
 			// 	$err_lbl.html('Please select Unit!');
 			// 	return false;
 			// }
 		}
 		if($chk_type=='tax'){
 			if($frm.find('.tax_percent').val()==0 || $frm.find('.tax_percent').val()>=100){
 				$err_lbl.html('Please enter valid Tax%!');
 				return false;
 			}
 		}
 		$.ajax({
 			url : "<?= site_url('aj_data') ?>",
 			data: 'action=chk_dup&type='+$chk_type+'&chk_fld=name&chk_val='+$chk_val+'&chk_id='+$id,
 			success: function(res){
 				res =$.trim(res);
 				if(res=='E')
 					$err_lbl.html($setting_type_str+' already exists!');
 				else{
 					$('.btn-save').html('Please wait...').attr('disabled',true);
 					$frm.submit();
 				}
 			}
 		}); 

 		
 	});  

 </script>
