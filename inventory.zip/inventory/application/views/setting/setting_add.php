<form id="entry-content" method="post" class="frm-save" style="display: none;">
	<div class="panel panel-default">
		<div class="panel-body">
			<?php if($setting_type =='product-category' || $setting_type =='city'){ ?>			
				<div class="col-md-6">
					<span class="badge-label"><?php echo ucfirst($setting_type_str);?> Name<span class="redstar">*</span></span>
					<input class="form-control mb25 name" name="name">
				</div>                 				
			<?php } elseif($setting_type =='unit'){ ?>
				<div class="col-md-3">
					<span class="badge-label"><?php echo ucfirst($setting_type_str);?> Name<span class="redstar">*</span></span>
					<input class="form-control mb25 name" name="name">
				</div>  
				<div class="col-md-3">
					<span class="badge-label">Parent Unit</span>
					<select class="select form-control parent_unit_id" name="parent_unit_id">
						<option value="0" >Select</option>
						<?php  
						$order=array();
						$order[] = array('name'=>'name','value'=>'asc');				
						$res = $this->setting_model->get_setting('unit',false,$order);
						if( count($res) > 0){
							foreach($res as $res1){ ?>
								<option value="<?= $res1["unit_id"] ?>" ><?= $res1["name"] ?> </option>
							<?php }  ?>
						<?php }  ?>
					</select>
				</div>
				<div class="col-md-2">
					<span class="badge-label">Conversion</span>
					<input class="form-control mb25 num-only conversion" name="conversion">
				</div>          
			<?php } elseif($setting_type =='product'){ ?>
				<div class="col-md-3">
					<span class="badge-label"><?php echo ucfirst($setting_type_str);?> Name<span class="redstar">*</span></span>
					<input class="form-control mb25 name" name="name">
				</div>  
				<div class="col-md-3">
					<span class="badge-label">Category<span class="redstar">*</span></span>
					<select class="select form-control product_category_id" name="product_category_id">
						<option value="0" >Select</option>
						<?php  
						$order=array();
						$order[] = array('name'=>'name','value'=>'asc');				
						$res = $this->setting_model->get_setting('product_category',false,$order);
						if( count($res) > 0){
							foreach($res as $res1){ ?>
								<option value="<?= $res1["product_category_id"] ?>" ><?= $res1["name"] ?> </option>
							<?php }  ?>
						<?php }  ?>
					</select>
				</div>
				<div class="col-md-3">
					<span class="badge-label">Default Unit</span>
					<select class="select form-control unit_id" name="unit_id">
						<option value="0" >Select</option>
						<?php  
						$order=array();
						$order[] = array('name'=>'name','value'=>'asc');				
						$res = $this->setting_model->get_setting('unit',false,$order);
						if( count($res) > 0){
							foreach($res as $res1){ ?>
								<option value="<?= $res1["unit_id"] ?>" ><?= $res1["name"] ?> </option>
							<?php }  ?>
						<?php }  ?>
					</select>
				</div>
				<div class="clearfix"></div>
				<div class="col-md-3 top15">
					<span class="badge-label">Purchase Price</span>
					<input class="form-control mb25 num-only pur_price" name="pur_price">
				</div> 
				<div class="col-md-3 top15">
					<span class="badge-label">Sales Price</span>
					<input class="form-control mb25 num-only sal_price" name="sal_price">
				</div>
			<?php } elseif($setting_type =='supplier' || $setting_type =='customer'){ ?>
				<style type="text/css">
					.top-alt{
						margin-top: 115px !important;
					}
				</style>
				<div class="col-md-3">
					<span class="badge-label"><?php echo ucfirst($setting_type_str);?> Name<span class="redstar">*</span></span>
					<input class="form-control mb25 name" name="name">
				</div>  
				<div class="col-md-3">
					<span class="badge-label">Mobile</span>
					<input class="form-control mb25 mobile" name="mobile">
				</div>       
				<div class="col-md-3">
					<span class="badge-label">Email</span>
					<input class="form-control mb25 email" name="email">
				</div>   
				<div class="clearfix"></div>    
				<div class="col-md-3 top15">
					<span class="badge-label">City</span>
					<select class="select form-control city_id" name="city_id">
						<option value="0" >Select</option>
						<?php  
						$order=array();
						$order[] = array('name'=>'name','value'=>'asc');				
						$res = $this->setting_model->get_setting('city',false,$order);
						if( count($res) > 0){
							foreach($res as $res1){ ?>
								<option value="<?= $res1["city_id"] ?>" ><?= $res1["name"] ?> </option>
							<?php }  ?>
						<?php }  ?>
					</select>
				</div>
				<div class="col-md-3 top15">
					<span class="badge-label">Address</span>
					<textarea style="height:108px !important;" name="address" class="form-control address" placeholder="Address"></textarea>
				</div>				
			<?php } elseif($setting_type =='tax'){ ?>
				<div class="col-md-3">
					<span class="badge-label"><?php echo ucfirst($setting_type_str);?> Name<span class="redstar">*</span></span>
					<input class="form-control mb25 name" name="name">
				</div>     
				<div class="col-md-2">
					<span class="badge-label">Tax %<span class="redstar">*</span></span>
					<input class="form-control mb25 num-only tax_percent" maxlength="5" name="tax_percent">
				</div> 
			<?php } ?>			

			<div class="col-md-3 top15">
				<span class="badge-label p-2">Status</span>
				<div class="switch top10">
					<label>Inactive<input type="checkbox" checked="true" name="status" value="A" >
						<span class="lever"></span> Active
					</label>
				</div>
			</div>
			<div class="col-md-3 pull-right top40 text-right top-alt">
				<label id="err_lbl" class="err_lbl"></label>&nbsp;&nbsp;
				<button class="btn button-save btn-save" title="Save" type="button"><i class="fa fa-check" aria-hidden="true"></i> Add</button>
				<button type="reset" title="Cancel" class="btn btn-clr button-cancel"><i class="fa fa-times" aria-hidden="true"></i> Clear</button>
			</div>
		</div>
	</div>
</form>