<section class="content-header">
	<h1 class="top-breadcrumb">&nbsp;</h1>
	<ol class="breadcrumb">
		<li><a href="<?php echo site_url('account/dashboard'); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
		<?php if(!empty($breadcrumbs)){ ?>
			<?php foreach($breadcrumbs as $key => $bc){ ?>
				<?php if($key == (count($breadcrumbs)-1)){ ?>
					<li class="active"><?php echo $bc['title']; ?></li>
				<?php }else{ ?>
					<li><a href="<?php echo $bc['href']; ?>"><?php echo $bc['title']; ?></a></li>
				<?php } ?>
			<?php } ?>
		<?php } ?>
		<a class="btn btn-back" href="javascript:window.history.go(-1);">Back</a>
	</ol>
</section>
<section class="content">
	<?php alert(); ?>
	<div class="row">
		<div class="col-lg-12">
			<div class="box box-success">				
				<div class="box-header with-border">
					<h3>Edit Company</h3>
				</div>
				<div class="box-body" style="overflow: auto;">
					<form id="entry-content" method="post" class="frm-save">
						<div class="panel1 panel-default">
							<div class="panel-body">
								<div class="col-md-4 top15">
									<span class="badge-label">Name<span class="redstar">*</span></span>
									<input class="form-control name" name="name" value="<?= $rec['name'] ?>">
								</div>
								<div class="col-md-4 top15">
									<span class="badge-label">Mobile</span>
									<input class="form-control mobile" name="mobile" value="<?= $rec['mobile'] ?>">
								</div>
								<div class="clearfix"></div>			
								<div class="col-md-4 top15">
									<span class="badge-label">Email</span>
									<input class="form-control email" name="email" value="<?= $rec['email'] ?>">
								</div>
								<div class="col-md-4 top15">
									<span class="badge-label">City</span>
									<select name="city_id" class="select form-control city_id">
										<option value="0" >Select</option>
										<?php  
										$order=array();
										$order[] = array('name'=>'name','value'=>'asc');        
										$opts = $this->setting_model->get_setting('city',false,$order);
										if( count($opts) > 0){
											foreach($opts as $opt){ ?>
												<option <?= $rec['city_id']==$opt['city_id']?' selected="true"':'';?> value="<?= $opt["city_id"] ?>" ><?= $opt["name"] ?> </option>
											<?php } } ?>
										</select>
									</div>
									<div class="clearfix"></div>			
									<div class="col-md-4 top15">
										<span class="badge-label">Address</span>
										<textarea style="height:108px !important;" name="address" class="form-control address" placeholder="Address"><?= $rec['address'] ?></textarea>
									</div>									
									<div class="col-md-4" style="text-align: right;margin-top: 120px;">
										<input type="hidden" name="company_id" value="<?= $rec['company_id'] ?>" />
										<label class="err_lbl"></label>&nbsp;&nbsp;
										<button class="btn btn-success button-save btn-save" title="Save" type="button"><i class="fa fa-check" aria-hidden="true"></i> Save</button>
										<button type="reset" title="Cancel" class="btn btn-clr button-cancel"><i class="fa fa-times" aria-hidden="true"></i> Clear</button>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</section>      
	<script>
		$('.select').select2();
		$(document).on('click','.btn-save',function(e){      
			$err_lbl= $(this).parent().find('.err_lbl');
			$err_lbl.html('');

			$frm = $('.frm-save');        
			$val = '';
			$frm.find('input:text').each(function(){
				$(this).val($.trim($(this).val()));
			});

			if($frm.find('.name').val() ==''){
				$err_lbl.html('Please enter Company name!');
				return false;
			}  

			$('.btn-save').html('Please wait...').attr('disabled',true);
			$frm.submit();
		});  

	</script>
