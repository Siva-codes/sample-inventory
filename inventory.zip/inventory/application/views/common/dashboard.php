<link rel="stylesheet" href="<?php echo base_url('assets/css/dashboard.css'); ?>">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons"  rel="stylesheet">
<section class="content-header">
	<h1>
		Dashboard
		<small>Control panel</small>
	</h1>
</section>
<section class="content">	
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-3 col-md-6 col-sm-6">
				<div class="card card-stats">
					<div class="card-header card-header-warning card-header-icon">
						<div class="card-icon">
							<i class="material-icons">receipt</i>
						</div>
						<p class="card-category">Sales</p>
						<h3 class="card-title">
							<small>₹&nbsp;</small><?=number_format($tots[0], 2);?>
						</h3>
					</div>
					<div class="card-footer">
						<div class="stats">
							<i class="fa fa-eye" aria-hidden="true"></i><a href="<?php echo site_url('sales-report'); ?>">View Detail</a>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-md-6 col-sm-6">
				<div class="card card-stats">
					<div class="card-header card-header-success card-header-icon">
						<div class="card-icon">
							<i class="material-icons">list_alt</i>
						</div>
						<p class="card-category">Purchase</p>
						<h3 class="card-title">
							<small>₹&nbsp;</small><?=number_format($tots[1], 2);?>
						</h3>
					</div>
					<div class="card-footer">
						<div class="stats">
							<i class="fa fa-eye" aria-hidden="true"></i><a href="<?php echo site_url('purchase-report'); ?>">View Detail</a>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-md-6 col-sm-6">
				<div class="card card-stats">
					<div class="card-header card-header-danger card-header-icon">
						<div class="card-icon">
							<i class="material-icons">widgets</i>
						</div>
						<p class="card-category">Product Categories</p>
						<h3 class="card-title"><?=$tots[2];?></h3>
					</div>
					<div class="card-footer">
						<div class="stats">
							<i class="fa fa-eye" aria-hidden="true"></i><a href="<?php echo site_url('product-category'); ?>">View Detail</a>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-md-6 col-sm-6">
				<div class="card card-stats">
					<div class="card-header card-header-info card-header-icon">
						<div class="card-icon">
							<i class="material-icons">storage</i>
						</div>
						<p class="card-category">Products</p>
						<h3 class="card-title"><?=$tots[3];?></h3>
					</div>
					<div class="card-footer">
						<div class="stats">
							<i class="fa fa-eye" aria-hidden="true"></i><a href="<?php echo site_url('product'); ?>">View Detail</a>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="row">
			<div class="col-lg-9">
				<div class="card mb-30">
					<div class="card-body" style="position: relative;margin-bottom: 28px !important;">
						<div class="card-header">
							<h4 class="card-title"><b>Purchase</b></h4>
						</div>
						<div id="pur_chart" style="padding-top: 10px;height: 400px; width: 100%;"></div>
					</div>
				</div>
			</div>
			<div class="col-lg-3">
				<div class="card mb-30">
					<div class="card-body">
						<div class="card-header">
							<h4 class="card-title"><b>Overview</b></h4>
						</div>
						<div class="media pt-2 pb-3 border-bottom">
							<div class="media-body">
								<h3 class="mt-1 mb-1 font-size-22 font-weight-normal">₹&nbsp;<?=number_format($overview1[0], 2);?></h3>
								<span class="text-muted">Total Purchase</span>
							</div>
							
						</div>
						<div class="media py-3 border-bottom">
							<div class="media-body">
								<h3 class="mt-1 mb-1 font-size-22 font-weight-normal">₹&nbsp;<?=number_format($overview1[1], 2);?></h3>
								<span class="text-muted">Total Purchase Return</span>
							</div>
							
						</div>
						<div class="media py-3 border-bottom">
							<div class="media-body">
								<h3 class="mt-1 mb-1 font-size-22 font-weight-normal"><?=$overview1[2];?></h3>
								<span class="text-muted">Purchase Bills</span>
							</div>
							
						</div>
						<div class="media pt-3">
							<div class="media-body">
								<h3 class="mt-1 mb-1 font-size-22 font-weight-normal"><?=$overview1[3];?></h3>
								<span class="text-muted">Purchase Return Bills</span>
							</div>
							
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="row">
			<div class="col-lg-9">
				<div class="card mb-30">
					<div class="card-body" style="position: relative;margin-bottom: 28px !important;">
						<div class="card-header">
							<h4 class="card-title"><b>Sales</b></h4>
						</div>
						<div id="sal_chart" style="padding-top: 10px;height: 400px; width: 100%;"></div>
					</div>
				</div>
			</div>
			<div class="col-lg-3">
				<div class="card mb-30">
					<div class="card-body">
						<div class="card-header">
							<h4 class="card-title"><b>Overview</b></h4>
						</div>
						<div class="media pt-2 pb-3 border-bottom">
							<div class="media-body">
								<h3 class="mt-1 mb-1 font-size-22 font-weight-normal">₹&nbsp;<?=number_format($overview2[0], 2);?></h3>
								<span class="text-muted">Total Sales</span>
							</div>
							
						</div>
						<div class="media py-3 border-bottom">
							<div class="media-body">
								<h3 class="mt-1 mb-1 font-size-22 font-weight-normal">₹&nbsp;<?=number_format($overview2[1], 2);?></h3>
								<span class="text-muted">Total Sales Return</span>
							</div>
							
						</div>
						<div class="media py-3 border-bottom">
							<div class="media-body">
								<h3 class="mt-1 mb-1 font-size-22 font-weight-normal"><?=$overview2[2];?></h3>
								<span class="text-muted">Sales Bills</span>
							</div>
							
						</div>
						<div class="media pt-3">
							<div class="media-body">
								<h3 class="mt-1 mb-1 font-size-22 font-weight-normal"><?=$overview2[3];?></h3>
								<span class="text-muted">Sales Return Bills</span>
							</div>
							
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="row">
			<div class="col-lg-12 col-xl-12">
				<div class="card mb-30">
					<div class="card-body">
						<div class="card-header">
							<h4 style="margin-bottom: 15px" class="card-title"><b>Recent Orders</b></h4>
						</div>
						<div class="height-365">
							<div class="table-responsive" id="rec_sals">								
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<script type="text/javascript" src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
<script type="text/javascript">  
	window.onload = function () {
		get_pur_chart();
		get_sal_chart();
		get_rec_sals();
	}
	function get_pur_chart(){
		$.ajax({
			url: '<?= site_url('aj_data_dashboard') ?>',            
			data: 'action=get_pur_chart',
			success: function(resp)
			{
				points=JSON.parse(resp);
				var chart = new CanvasJS.Chart("pur_chart", { 
					dataPointWidth: 60,           
					axisX:{
						gridColor: "#f4f4f4",
						lineThickness: 1,
						lineColor: "#f4f4f4",
						labelFontColor: "#333"
					},
					axisY:{          
						gridColor: "#f4f4f4",
						lineThickness: 1,
						lineColor: "#f4f4f4",
						labelFontColor: "#333"
					},
						data: [  //array of dataSeries     
						{ //dataSeries - first quarter
							/*** Change type "column" to "bar", "area", "line" or "pie"***/        
							type: "column",
							color: "#6389ce", 
							showInLegend: true,
							name: "Purchase",
							dataPoints:points.a
						},
						{ //dataSeries - second quarter

							type: "column",
							color: "#ce63bc",
							showInLegend: true,  
							name: "Purchase Return",                
							dataPoints:points.b
						}
						]
					});
				chart.render();					
			}           
		});	
	}
	function get_sal_chart(){
		$.ajax({
			url: '<?= site_url('aj_data_dashboard') ?>',            
			data: 'action=get_sal_chart',
			success: function(resp)
			{
				points=JSON.parse(resp);
				var chart = new CanvasJS.Chart("sal_chart", {            
					dataPointWidth: 60,           
					axisX:{
						gridColor: "#f4f4f4",
						lineThickness: 1,
						lineColor: "#f4f4f4",
						labelFontColor: "#333"
					},
					axisY:{          
						gridColor: "#f4f4f4",
						lineThickness: 1,
						lineColor: "#f4f4f4",
						labelFontColor: "#333"
					},
					data: [
					{
						type: "column",
						color: "#ff5a5f", 
						showInLegend: true,
						name: "Sales",
						dataPoints:points.a
					},
					{
						type: "column",
						color: "#49a4bd",
						showInLegend: true,  
						name: "Sales Return",                
						dataPoints:points.b
					}
					]
				});
				chart.render();	
			}           
		});
	}
	function get_rec_sals(){
		$.ajax({
			url: '<?= site_url('aj_data_dashboard') ?>',            
			data: 'action=get_rec_sals',
			success: function(resp)
			{
				 $('#rec_sals').html(resp);
			}           
		});
	}
</script>