<!DOCTYPE html>
<html>
<head>
 <meta charset="utf-8">
 <meta http-equiv="X-UA-Compatible" content="IE=edge">
 <title><?php echo isset($meta_title)?$meta_title.' | ':''; ?>Inventory Admin</title>
 <!-- Tell the browser to be responsive to screen width -->
 <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
 <!-- Bootstrap 3.3.5 -->
 <link href="<?php echo base_url('assets/css/icons/icomoon/styles.css'); ?>" rel="stylesheet" type="text/css">

 <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css'); ?>" />
 <!-- Font Awesome -->
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">

 <!-- Theme style -->
 <link rel="stylesheet" href="<?php echo base_url('assets/css/AdminLTE.min.css'); ?>">
 <link rel="stylesheet" href="<?php echo base_url('assets/css/skins/skin-blue.min.css'); ?>">
 <link rel="stylesheet" href="<?php echo base_url('assets/css/components.css'); ?>">
 <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css'); ?>">
 <!-- bootstrap wysihtml5 - text editor -->
 <link rel="stylesheet" href="<?php echo base_url('assets/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css'); ?>">
 <link rel="icon" type="image/png" href="<?php echo base_url('assets/img/favi-icon.png'); ?>" sizes="32x32" />
 <script type="text/javascript" src="<?php echo base_url('assets/js/core/libraries/jquery.min.js'); ?>"></script>
 <script type="text/javascript" src="<?php echo base_url('assets/js/core/libraries/jquery-ui.js'); ?>"></script>

   <!----------------datatables---------->
   <link href="assets/plugins/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">
  <!-- DataTables Responsive CSS -->
  <link href="assets/plugins/datatables-responsive/dataTables.responsive.css" rel="stylesheet">
  <script type="text/javascript" src="assets/tableExport/tableExport.js"></script>
  <script type="text/javascript" src="assets/tableExport/jquery.base64.js"></script>
  <script type="text/javascript" src="assets/tableExport/html2canvas.js"></script>
  <script type="text/javascript" src="assets/tableExport/jspdf/libs/sprintf.js"></script>
  <script type="text/javascript" src="assets/tableExport/jspdf/jspdf.js"></script>
  <script type="text/javascript" src="assets/tableExport/jspdf/libs/base64.js"></script>
  
  <script type="text/javascript" src="assets/tableExport/jspdf/libs/sprintf.js"></script>
  <script type="text/javascript" src="assets/tableExport/jspdf/jspdf.js"></script>
  <script type="text/javascript" src="assets/tableExport/jspdf/libs/base64.js"></script>

  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.18/css/dataTables.bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/fixedheader/3.1.4/css/fixedHeader.bootstrap.min.css">

  <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.2/css/responsive.bootstrap.min.css">

  <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>

  <script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap4.min.js"></script>
  <script src="https://cdn.datatables.net/rowreorder/1.2.7/js/dataTables.rowReorder.min.js"></script>

  <!-- Select2 css and js file -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
  <!----------------jquery alert plugin---------->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.js"></script>

 <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
 <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style type="text/css">
      .controls > .error{color: #f00;}
      .error input{border-color: #f00;}
      .error input:focus{border-color: #f00 !important;}
      .table-hover > tbody > tr {
       transition: background-color 0.5s ease;
       /*background-color: #fff;*/
     }
     .table-hover > tbody > tr:hover {
       transition: background-color 0.5s ease;
       background-color: #d6d6c2;
     }
   </style>    
 </head>
 <body class="hold-transition skin-blue sidebar-mini body-bg">
   <div class="wrapper">
    <header class="main-header pri">
     <!-- Logo -->
     <a href="<?php echo site_url('dashboard'); ?>" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>IV</b></span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>Inventory</b></span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->   
    <nav class="navbar navbar-static-top" role="navigation">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
       <span class="sr-only">Toggle navigation</span>
     </a>

     <div class="navbar-custom-menu">
       <ul class="nav navbar-nav">

        <!-- User Account: style can be found in dropdown.less -->
        <li class="dropdown user user-menu">
         <a href="#" class="dropdown-toggle" data-toggle="dropdown">
          <img src="<?php echo admin_profile_picture(); ?>" class="user-image" alt="User Image">
          <span class="hidden-xs"><?php echo $admin_name = admin_detail('name'); ?></span>
        </a>
        <ul class="dropdown-menu">
          <!-- User image -->
          <li class="user-header">
           <img src="<?php echo admin_profile_picture(); ?>" class="img-circle" alt="User Image">
           <p>
            <?php echo $admin_name; ?>
            <small>Administrator</small>
          </p>
        </li>
        <!-- Menu Footer-->
        <li class="user-footer">
         <div class="pull-left">
          <a href="<?php echo site_url('profile'); ?>" class="btn btn-default btn-flat">Profile</a>
        </div>
        <div class="pull-right">
          <a href="<?php echo site_url('logout'); ?>" class="btn btn-default btn-flat">Sign out</a>
        </div>
      </li>
    </ul>
  </li>
</ul>
</div>
</nav>
</header> 
<aside class="main-sidebar pri">
 <section class="sidebar">
  <?php 
  $cur_cls = $this->router->fetch_class();
  $cur_mth = $this->router->fetch_method();

  $dashboard_cls = $cur_cls=='account' && $cur_mth=='dashboard'?'active':'';  
  
  $set_cls = $cur_cls=='setting'?'active':'';   
  $cat_cls = $cur_cls=='setting' && strpos($this->uri->segment(2), 'category') !== false?'active':'';   
  $prod_cls= $cur_cls=='setting' && !$cat_cls && strpos($this->uri->segment(2), 'product') !== false?'active':'';    

  $users = ($cur_cls=='setting' && ($this->uri->segment(2)=='users-list' || $this->uri->segment(2)=='view-users'))?'active':'';   
  $rpt_cls = $cur_cls=='report'?'active':'';  

  $tr_cls = $cur_cls=='purchase' || $cur_cls=='sales' || (!$set_cls && !$rpt_cls) ?'active':'';  
  ?>
  <ul class="sidebar-menu">
   <li class="header" style="height: 21px;">&nbsp;</li>
   <li class="<?php echo $dashboard_cls; ?>">
    <a href="<?php echo site_url('dashboard'); ?>"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
  </li>  
  <li class="treeview <?php echo $set_cls; ?>">
   <a href="javascript:void(0);">
    <i class="fa fa-th"></i> <span>Settings</span> <i class="fa fa-angle-left pull-right"></i>
  </a>
  <ul class="treeview-menu">
    <li><a href="<?php echo site_url('company'); ?>"><i class="fa fa-file-text"></i><span>Company</span></a></li>       
    <li><a href="<?php echo site_url('product-category'); ?>"><i class="fa fa-file-text"></i><span>Product Category</span></a></li>   
    <li><a href="<?php echo site_url('product'); ?>"><i class="fa fa-file-text"></i><span>Product</span></a></li>   
    <li><a href="<?php echo site_url('unit'); ?>"><i class="fa fa-file-text"></i><span>Unit</span></a></li>   
    <li><a href="<?php echo site_url('supplier'); ?>"><i class="fa fa-file-text"></i><span>Supplier</span></a></li>   
    <li><a href="<?php echo site_url('customer'); ?>"><i class="fa fa-file-text"></i><span>Customer</span></a></li>   
    <li><a href="<?php echo site_url('tax'); ?>"><i class="fa fa-file-text"></i><span>Tax</span></a></li>       
    <li><a href="<?php echo site_url('city'); ?>"><i class="fa fa-file-text"></i><span>City</span></a></li>
  </ul>
</li> 
<li class="treeview <?php echo $tr_cls; ?>">
   <a href="javascript:void(0);">
    <i class="fa fa-th"></i> <span>Transactions</span> <i class="fa fa-angle-left pull-right"></i>
  </a>
  <ul class="treeview-menu">
    <li><a href="<?php echo site_url('purchase'); ?>"><i class="fa fa-file-text"></i><span>Purchase</span></a></li>       
    <li><a href="<?php echo site_url('purchase-return'); ?>"><i class="fa fa-file-text"></i><span>Purchase Return</span></a></li>       
    <li><a href="<?php echo site_url('sales'); ?>"><i class="fa fa-file-text"></i><span>Sales</span></a></li>       
    <li><a href="<?php echo site_url('sales-return'); ?>"><i class="fa fa-file-text"></i><span>Sales Return</span></a></li>       
  </ul>
</li> 
<li class="treeview <?php echo $rpt_cls; ?>">
   <a href="javascript:void(0);">
    <i class="fa fa-th"></i> <span>Reports</span> <i class="fa fa-angle-left pull-right"></i>
  </a>
  <ul class="treeview-menu">
    <li><a href="<?php echo site_url('purchase-report'); ?>"><i class="fa fa-file-text"></i><span>Purchase</span></a></li>       
    <li><a href="<?php echo site_url('purchase-return-report'); ?>"><i class="fa fa-file-text"></i><span>Purchase Return</span></a></li>       
    <li><a href="<?php echo site_url('sales-report'); ?>"><i class="fa fa-file-text"></i><span>Sales</span></a></li>       
    <li><a href="<?php echo site_url('sales-return-report'); ?>"><i class="fa fa-file-text"></i><span>Sales Return</span></a></li>       
    <li><a href="<?php echo site_url('stock-report'); ?>"><i class="fa fa-file-text"></i><span>Stock</span></a></li>       
  </ul>
</li> 
</li>
</ul>
</section>
</aside>
<div class="content-wrapper" style="min-height: 680px;">