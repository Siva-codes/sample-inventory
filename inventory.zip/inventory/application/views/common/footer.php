<!-- /.content -->
</div>
<!-- /.content-wrapper -->
<footer class="main-footer pri">
  <strong>Copyright &copy; <?php echo date('Y'); ?> <a href="<?php echo site_url(); ?>">Inventory</a>.</strong> All rights reserved.
</footer>

</div>

<!-- ./wrapper -->
<!-- jQuery 2.1.4 sort--> 
<script src="<?php echo base_url('assets/plugins/noty/noty.min.js'); ?>"></script>
<!-- jQuery UI 1.11.4 --> 
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
 $.widget.bridge('uibutton', $.ui.button);
</script>
<!-- Bootstrap 3.3.5 -->
<script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js'); ?>"></script>

<!-- Bootstrap WYSIHTML5 -->
<script src="<?php echo base_url('assets/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js'); ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/plugins/validation/validate.min.js'); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url('assets/js/app.min.js'); ?>"></script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/animate.css'); ?>" />
<!-- <script type="text/javascript">$('.ta-editor').wysihtml5();</script> -->
<script type="text/javascript">
    $(document).on("keypress", ".num-only", function(e){
   var charCode = (e.which) ? e.which : e.keyCode;

   if (charCode > 31 && (charCode < 48 || charCode > 57)) {
    return false;
  }
  return true;
});
  $(document).on("keypress", ".num-frac-only", function(e){
   var charCode = (e.which) ? e.which : e.keyCode;

   if ((charCode > 31 && (charCode < 48 || charCode > 57)) && charCode!=46) {
    return false;
  }

  if(charCode==46){
    $val = e.target.value;
    if($val.includes("."))  
      return false;
    else
      return true;
  }
  else
    return true;        
  });   
  
  $(document).ready(function(){
    $('.sort-table tbody').sortable({
      axis: 'y',
      handle:'.handle',
      update: function (event, ui) {
        var sno = 1;
        $('.sort-table tbody tr').each(function(){
          $(this).find('.srt-ord').val(sno);
          sno++;
        });
      }
    });
  }); 
  function validate_date(inputText){
    var dateformat=/^(0?[1-9]|[12][0-9]|3[01])[\/\-](0?[1-9]|1[012])[\/\-]\d{4}$/;
    if(inputText.match(dateformat)){
      var opera1=inputText.split('/');
      var opera2=inputText.split('-');
      lopera1=opera1.length;lopera2=opera2.length;

      if(lopera1>1){
        var pdate=inputText.split('/');
      }
      else if(lopera2>1){
        var pdate=inputText.split('-');
      }

      var dd=parseInt(pdate[0]);
      var mm=parseInt(pdate[1]);
      var yy=parseInt(pdate[2]);
      var ListofDays=[31,28,31,30,31,30,31,31,30,31,30,31];
      if(mm==1||mm>2){
        if(dd>ListofDays[mm-1]){
          return false;
        }
      }
      if(mm==2){
        var lyear=false;
        if((!(yy%4)&&yy%100)||!(yy%400)){
          lyear=true;
        }
        if((lyear==false)&&(dd>=29)){
          return false;
        }
        if((lyear==true)&&(dd>29)){
          return false;
        }
      }
    }
    else{
      return false;
    }

    return true;
  }
</script>
<style type="text/css">
  .btn-primary {background-color: #4d9ecd;}
  .alert{border-radius: 0;background-color:#fff !important;color:#444 !important;}
  .has-error label {color: #dd4b39 !important; }
  .has-success label{color: #00a65a !important;}
  .alert-success{border-left: 6px solid #00a65a;}
  .alert-info{border-left: 6px solid #00c0ef;}
  .alert-danger{border-left: 6px solid #dd4b39;}
  .alert a{color:#444 !important;}
  .table{margin-bottom: 0;}
  .brws-img-btn i{color: #fff;font-size: 14px;}
  .brws-img-btn:hover{background-color: #2172a1;}
  .brws-img-file{display: none !important;}
  .brws-img-btn {background-color: #3c8dbc; cursor: pointer; float: right; padding-bottom: 6px; padding-top: 6px; position: relative; text-align: center; top: -37px; transition: background 0.2s ease 0s; width: 41px; margin-right: 5px;}
  .ui-tooltip{display: none !important;}
</style>
</body>
</html>