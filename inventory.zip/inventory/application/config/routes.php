<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = "account/login";
$route['404_override'] = '';

$route['login'] = 'account/login';
$route['dashboard'] = 'account/dashboard';
$route['profile'] = 'account/profile';
$route['logout'] = 'account/logout';

$route['company'] = 'setting/edit_company';

$settings = array('product-category','product','supplier','customer','tax','unit','city');
foreach ($settings as $key => $setting) {
  $route[$setting] = 'setting/setting_list/'.$setting;
}

$route['purchase'] = 'transaction/purchase/B';
$route['purchase-return'] = 'transaction/purchase/R';

$route['edit-purchase/(:any)'] = 'transaction/purchase/B/$1';
$route['edit-purchase-return/(:any)'] = 'transaction/purchase/R/$1';

$route['purchase-report'] = 'report/purchase/B';
$route['purchase-return-report'] = 'report/purchase/R';

$route['sales'] = 'transaction/sales/B';
$route['sales-return'] = 'transaction/sales/R';

$route['edit-sales/(:any)'] = 'transaction/sales/B/$1';
$route['edit-sales-return/(:any)'] = 'transaction/sales/R/$1';

$route['sales-report'] = 'report/sales/B';
$route['sales-return-report'] = 'report/sales/R';

$route['stock-report'] = 'report/stock';
$route['translate_uri_dashes'] = FALSE;

/* End of file routes.php */
/* Location: ./application/config/routes.php */


