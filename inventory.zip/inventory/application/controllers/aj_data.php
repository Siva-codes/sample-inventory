<?php 

Class Aj_data extends AdminController
{

  function index(){
// if(empty($this->session->userdata('admin_redirect_link'))  {
//   echo "<script>window.location.href='login.php';</script>";
// }

    $action = $_GET['action'];

    switch ($action) {
      case 'chk_dup':{
        $type=$_GET['type'];
        $type = str_replace('-', '_', $type);
        $pri_id=$type.'_id';        

        $chk_fld = $_GET['chk_fld'];
        $chk_val = $_GET['chk_val'];

        $condition[] = array('name'=>$chk_fld,'value'=>$chk_val);

        if(!empty($_GET['chk_fld1']) && !empty($_GET['chk_val1']))
          $condition[] = array('name'=>$_GET['chk_fld1'],'value'=>$_GET['chk_val1']);

        if(!empty($_GET['chk_id']))
          $condition[] = array('name'=>$pri_id.' != ','value'=>$_GET['chk_id']);

        $res = $this->setting_model->get_setting($type,$condition);
       // echo $this->db->last_query();exit();
       //  echo "<pre>";print_r($res);exit();

        if(!empty($res))
         echo "E";
       else
        echo "S";
      break; 
    }
    case "product_category_edit":
    case "city_edit":
    {
      $table = str_replace('_edit', '', $action);
      $pri_id=$table.'_id';

      $condition=array();
      $condition[] = array('name'=>$pri_id,'value'=>$_GET['id']);
      $res = $this->setting_model->get_setting($table,$condition);?>
      <input type="hidden" name="<?=$pri_id?>" value="<?= $res[$pri_id] ?>" />
      <div class="row">
        <div class="col-md-12 top15">
          <span class="badge-label">Name</span>
          <input class="form-control name" name="name" value="<?= $res['name'] ?>">
        </div>
        <div class="col-md-12 top15">
          <span class="badge-label p-2">Status</span>
          <div class="switch top10">
            <label>Inactive
              <input type="checkbox" <?= $res['status']=='A'?'checked="true"':''; ?> name="status" value="A" >
              <span class="lever"></span> Active
            </label>
          </div>
        </div>
      </div>
      <?php
      break;
    }
    case "unit_edit":{
      $condition=array();
      $condition[] = array('name'=>'unit_id','value'=>$_GET['id']);
      $res = $this->setting_model->get_setting('unit',$condition);?>
      <style type="text/css"> 
        .modal-dialog{
          width: 400px;
        }
      </style>
      <input type="hidden" name="unit_id" value="<?= $res['unit_id'] ?>" />
      <div class="row">
        <div class="col-md-12 top15">
          <span class="badge-label">Name</span>
          <input class="form-control name" name="name" value="<?= $res['name'] ?>">
        </div>
        <div class="col-md-12 top15">
          <span class="badge-label">Parent Unit</span>
          <select name="parent_unit_id" class="select form-control parent_unit_id">
            <option value="0" >Select</option>
            <?php  
            $order=array();
            $order[] = array('name'=>'name','value'=>'asc');        
            $opts = $this->setting_model->get_setting('unit',false,$order);
            if( count($opts) > 0){
              foreach($opts as $opt){ ?>
                <option <?= $res['parent_unit_id']==$opt['unit_id']?' selected="true"':'';?> value="<?= $opt["unit_id"] ?>" ><?= $opt["name"] ?> </option>
              <?php } } ?>
            </select>
          </div>
          <div class="col-md-12 top15">
            <span class="badge-label">Conversion</span>
            <input class="form-control conversion" name="conversion" value="<?= $res['conversion'] ?>">
          </div>
          <div class="col-md-12 top15">
            <span class="badge-label p-2">Status</span>
            <div class="switch top10">
              <label>Inactive
                <input type="checkbox" <?= $res['status']=='A'?'checked="true"':''; ?> name="status" value="A" >
                <span class="lever"></span> Active
              </label>
            </div>
          </div>
        </div>
        <script type="text/javascript">
          $('.select').select2();
        </script>
        <?php
        break;
      }
      case "product_edit":{
        $condition=array();
        $condition[] = array('name'=>'product_id','value'=>$_GET['id']);
        $res = $this->setting_model->get_setting('product',$condition);?>
        <style type="text/css"> 
          .modal-dialog{
            width: 500px;
          }
        </style>
        <input type="hidden" name="product_id" value="<?= $res['product_id'] ?>" />
        <div class="row">
          <div class="col-md-12 top15">
            <span class="badge-label">Name</span>
            <input class="form-control name" name="name" value="<?= $res['name'] ?>">
          </div>
          <div class="col-md-12 top15">
            <span class="badge-label">Category</span>
            <select name="product_category_id" class="select form-control product_category_id">
              <option value="0" >Select</option>
              <?php  
              $order=array();
              $order[] = array('name'=>'name','value'=>'asc');        
              $opts = $this->setting_model->get_setting('product_category',false,$order);
              if( count($opts) > 0){
                foreach($opts as $opt){ ?>
                  <option <?= $res['product_category_id']==$opt['product_category_id']?' selected="true"':'';?> value="<?= $opt["product_category_id"] ?>" ><?= $opt["name"] ?> </option>
                <?php } } ?>
              </select>
            </div>
            <div class="col-md-12 top15">
              <span class="badge-label">Unit</span>
              <select name="unit_id" class="select form-control unit_id">
                <option value="0" >Select</option>
                <?php  
                $order=array();
                $order[] = array('name'=>'name','value'=>'asc');        
                $opts = $this->setting_model->get_setting('unit',false,$order);
                if( count($opts) > 0){
                  foreach($opts as $opt){ ?>
                    <option <?= $res['unit_id']==$opt['unit_id']?' selected="true"':'';?> value="<?= $opt["unit_id"] ?>" ><?= $opt["name"] ?> </option>
                  <?php } } ?>
                </select>
              </div>
              <div class="col-md-12 top15">
                <span class="badge-label">Purchase Price</span>
                <input class="form-control pur_price num-only" name="pur_price" value="<?= $res['pur_price'] ?>">
              </div>
              <div class="col-md-12 top15">
                <span class="badge-label">Sales Price</span>
                <input class="form-control sal_price num-only" name="sal_price" value="<?= $res['sal_price'] ?>">
              </div>
              <div class="col-md-12 top15">
                <span class="badge-label p-2">Status</span>
                <div class="switch top10">
                  <label>Inactive
                    <input type="checkbox" <?= $res['status']=='A'?'checked="true"':''; ?> name="status" value="A" >
                    <span class="lever"></span> Active
                  </label>
                </div>
              </div>
            </div>
            <script type="text/javascript">
              $('.select').select2();
            </script>
            <?php
            break;
          }
          case "supplier_edit":
          case "customer_edit":
          {
            $table = str_replace('_edit', '', $action);
            $pri_id=$table.'_id';

            $condition=array();
            $condition[] = array('name'=>$pri_id,'value'=>$_GET['id']);
            $res = $this->setting_model->get_setting($table,$condition);?>
            <input type="hidden" name="<?=$pri_id?>" value="<?= $res[$pri_id] ?>" />

            <div class="row">
              <div class="col-md-12 top15">
                <span class="badge-label">Name</span>
                <input class="form-control name" name="name" value="<?= $res['name'] ?>">
              </div>
              <div class="col-md-12 top15">
                <span class="badge-label">Mobile</span>
                <input class="form-control mobile" name="mobile" value="<?= $res['mobile'] ?>">
              </div>
              <div class="col-md-12 top15">
                <span class="badge-label">Email</span>
                <input class="form-control email" name="email" value="<?= $res['email'] ?>">
              </div>
              <div class="col-md-12 top15">
                <span class="badge-label">City</span>
                <select name="city_id" class="select form-control city_id">
                  <option value="0" >Select</option>
                  <?php  
                  $order=array();
                  $order[] = array('name'=>'name','value'=>'asc');        
                  $opts = $this->setting_model->get_setting('city',false,$order);
                  if( count($opts) > 0){
                    foreach($opts as $opt){ ?>
                      <option <?= $res['city_id']==$opt['city_id']?' selected="true"':'';?> value="<?= $opt["city_id"] ?>" ><?= $opt["name"] ?> </option>
                    <?php } } ?>
                  </select>
                </div>
                <div class="col-md-12 top15">
                  <span class="badge-label">Address</span>
                  <textarea style="height:108px !important;" name="address" class="form-control address" placeholder="Address"><?= $res['address'] ?></textarea>
                </div>
                <div class="col-md-12 top15">
                  <span class="badge-label p-2">Status</span>
                  <div class="switch top10">
                    <label>Inactive
                      <input type="checkbox" <?= $res['status']=='A'?'checked="true"':''; ?> name="status" value="A" >
                      <span class="lever"></span> Active
                    </label>
                  </div>
                </div>
              </div>
              <script type="text/javascript">
                $('.select').select2();
              </script>
              <?php
              break;
            }
            case "tax_edit":{
              $condition=array();
              $condition[] = array('name'=>'tax_id','value'=>$_GET['id']);
              $res = $this->setting_model->get_setting('tax',$condition);?>
              <style type="text/css"> 
                .modal-dialog{
                  width: 400px;
                }
              </style>
              <input type="hidden" name="tax_id" value="<?= $res['tax_id'] ?>" />
              <div class="row">
                <div class="col-md-12 top15">
                  <span class="badge-label">Name</span>
                  <input class="form-control name" name="name" value="<?= $res['name'] ?>">
                </div>
                <div class="col-md-12 top15">
                  <span class="badge-label">Tax %</span>
                  <input class="form-control tax_percent num-only" maxlength="5" name="tax_percent" value="<?= $res['tax_percent'] ?>">
                </div>
                <div class="col-md-12 top15">
                  <span class="badge-label p-2">Status</span>
                  <div class="switch top10">
                    <label>Inactive
                      <input type="checkbox" <?= $res['status']=='A'?'checked="true"':''; ?> name="status" value="A" >
                      <span class="lever"></span> Active
                    </label>
                  </div>
                </div>
              </div>
              <?php
              break;
            }

            case "del_setting":{  
              $type=$_GET['type'];
              $pri_id=$type.'_id';
              $id = $_GET['id'];

              if ($type !='purchase' || $type !='sales'){
                $msg = $this->setting_model->check_setting($type,$id,$_GET['type_str']);
                if ($msg != '1'){
                  echo $msg;
                  return false;
                }
              } 

              $this->db->where($type.'.'.$pri_id,$id);
              $this->db->delete($type);      

              if($type=='purchase'){
                $this->db->where('purchase_id',$id);
                $this->db->delete('purchase_dtl');

                if(strpos(strtolower($_GET['type_str']),'bill')!== false)
                  $this->db->where('bill_type','PB');
                else
                  $this->db->where('bill_type','PR');

                $this->db->where('bill_id',$id);
                $this->db->delete('stock');
              }
              elseif($type=='sales'){
                $this->db->where('sales_id',$id);
                $this->db->delete('sales_dtl');

                if(strpos(strtolower($_GET['type_str']),'bill')!== false)
                  $this->db->where('bill_type','SB');
                else
                  $this->db->where('bill_type','SR');

                $this->db->where('bill_id',$id);
                $this->db->delete('stock');
              }

              $this->session->set_flashdata("alert_success",$_GET['type_str']." deleted successfully!");      
              echo "S";
              break;
            }

          } 
        }
      }

