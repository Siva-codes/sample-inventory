<?php 

Class Setting extends AdminController
{
	function __construct(){
		parent::__construct();
	}

	function get_setting_type_str($setting_type){
		$setting_type_str = str_replace('-', ' ', $setting_type);
		$setting_type_str = str_replace('_', ' ', $setting_type_str);
		$setting_type_str = str_replace('img', 'image', $setting_type_str);
		$setting_type_str = str_replace('ref', 'referral', $setting_type_str);
		$setting_type_str = ucwords($setting_type_str);
		return $setting_type_str;
	}

	function setting_list($setting_type){
		$tbl_name = str_replace('-', '_', $setting_type);
		$data['tbl_name']=$tbl_name;
		$data['setting_type']=$setting_type;
		$setting_type_str = $this->get_setting_type_str($setting_type);				
		$data['setting_type_str']=$setting_type_str;

		if($this->input->server('REQUEST_METHOD') === 'POST'){
			$save = $this->input->post();
			$save['status']=$save['status']!='A'?'I':'A';

			if(isset($save[$tbl_name.'_id'])){
				$save['modified_by'] = $this->session->userdata('admin_id');
				$save['modified_date'] = time();			
			}
			else{
				$save['created_by'] = $this->session->userdata('admin_id');
				$save['created_date'] = time();			
			}			

			$this->setting_model->save_setting($tbl_name,$save);			

			$this->session->set_flashdata("alert_success",$setting_type_str." saved successfully!");			
			redirect($setting_type);				
		}		

		$data['meta_title'] = $setting_type_str;
		$data['page_title'] = $setting_type_str;

		$select=$join=$group=$condition=$join=array();
		
		// // echo "<pre>";print_r($this->db->last_query());die;
		// $tot_rows = $this->setting_model->get_setting_list($tbl_name,$condition,$order,$query_filter,true,false);		
		
		$data['breadcrumbs'][] = array('title'=>$setting_type_str, 'href'=> "");			

		$order[] = array('name'=>$tbl_name.'_id','value'=>'desc');				

		switch ($setting_type) {
			case 'product-category':			
			case 'city':			
			$data['data_hdrs'] = array('Name','Status');			
			$data['data_cols'] = array('name','status');
			$data['tbl_hdr_widths'] = array('description','status');
			break;

			case 'unit':
			$select = array('unit.*','a.name as parent_name');
			$join[] = array('table_name' => 'unit as a' ,'condition' => 'unit.parent_unit_id =a.unit_id' ,'join_type' => 'left');
			$group[] = array('value'=>'unit.unit_id');
			$data['data_hdrs'] = array('Name','Parent Unit','Conversion','Status');
			$data['data_cols'] = array('name','parent_name','conversion','status');
			$data['tbl_hdr_widths'] = array('name','name','name','status');			
			break;

			case 'product':
			$select = array('product.*','product_category.name as cat_name','unit.name as unit_name');
			$join[] = array('table_name' => 'product_category' ,'condition' => 'product_category.product_category_id =product.product_category_id' ,'join_type' => 'left');
			$join[] = array('table_name' => 'unit' ,'condition' => 'unit.unit_id =product.unit_id' ,'join_type' => 'left');
			$group[] = array('value'=>'product.product_id');
			$data['data_hdrs'] = array('Name','Category','Unit','Pur.Price','Sal.Price','Status');
			$data['data_cols'] = array('name','cat_name','unit_name','pur_price','sal_price','status');
			$data['tbl_hdr_widths'] = array('name','name','name','name','name','status');			
			break;

			case 'supplier':
			case 'customer':
			$select = array($tbl_name.'.*','city.name as city_name');
			$join[] = array('table_name' => 'city' ,'condition' => 'city.city_id ='.$tbl_name.'.city_id' ,'join_type' => 'left');
			$group[] = array('value'=>$tbl_name.'.'.$tbl_name.'_id');
			$data['data_hdrs'] = array('Name','Mobile','Email','City','Address','Status');
			$data['data_cols'] = array('name','mobile','email','city_name','address','status');
			$data['tbl_hdr_widths'] = array('name','name','name','name','description','status');			
			break;

			case 'tax':			
			$data['data_hdrs'] = array('Name','Percent','Status');			
			$data['data_cols'] = array('name','tax_percent','status');
			$data['tbl_hdr_widths'] = array('name','name','status');
			break;
		}

		$data['data_hdrs'][] ='Action';
		$data['data_cols'][] ='action';
		$data['tbl_hdr_widths'][] ='action';		

		$data['recs'] = $this->setting_model->get_setting_list($tbl_name,$condition,$order,false,false,false,$select,$join,$group);

		$this->load->view('common/header',$data);
		$this->load->view('setting/setting_list',$data);
		$this->load->view('common/footer',$data);
	}

	function edit_company(){
		if($this->input->server('REQUEST_METHOD') === 'POST'){
			$save = $this->input->post();
			$save['modified_by'] = $this->session->userdata('admin_id');
			$save['modified_date'] = time();		
			$this->setting_model->save_setting('company',$save);			

			$this->session->set_flashdata("alert_success","Company saved successfully!");			
			redirect('company');							
		}		

		$data['meta_title'] = "Edit Company";
		$data['page_title'] = "Edit Company";		
		$data['breadcrumbs'][] = array('title'=>"Edit Company", 'href'=> "");			
		$data['rec'] = $this->setting_model->get_setting('company');

		$this->load->view('common/header',$data);
		$this->load->view('setting/edit_company',$data);
		$this->load->view('common/footer',$data);
	}
}

?>