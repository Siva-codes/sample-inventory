<?php 

Class Transaction extends AdminController
{
	function __construct(){
		parent::__construct();
	}

	function purchase($bill_type=false,$purchase_id=false){
		if($this->input->server('REQUEST_METHOD') === 'POST'){
			$post = $this->input->post();

						//echo "<pre>";print_r($post);exit;

			$bill_date = str_replace("/","-", $post['bill_date']);
			list($dy, $mn, $yr) = explode('-', $bill_date);
			$bill_date = mktime(0,0,0,$mn,$dy,$yr);

			$save['bill_no'] = $post['bill_no'];	
			$save['bill_type'] = $post['bill_type'];
			$save['bill_date'] = $bill_date;
			$save['pay_type'] = $post['pay_type'];
			$save['supplier_id'] = $post['supplier_id'];

			$save['tot_amt'] = $post['tot_amt'];	
			$save['tax_id'] = $post['tax_id'];	
			$save['tax_amt'] = $post['tax_amt'];
			$save['bill_amt'] = $post['bill_amt'];			

			if (!empty($post['purchase_id'])){
				$save['purchase_id'] = $post['purchase_id'];
				$save['modified_by'] = $this->session->userdata('admin_id');
				$save['modified_date'] = time();
				$purchase_id = $post['purchase_id'];
				$this->setting_model->save_setting('purchase',$save);

				$this->db->where('purchase_id',$purchase_id);
				$this->db->delete('purchase_dtl');

				$this->db->where('bill_type','P'.$bill_type);
				$this->db->where('bill_id',$purchase_id);
				$this->db->delete('stock');
			}
			else{
				$save['created_by'] = $this->session->userdata('admin_id');
				$save['created_date'] = time();	
				$purchase_id = $this->setting_model->save_setting('purchase',$save,true);
			}

			foreach ($post['prod'] as $key => $prod) {
				if (!empty($prod['amt'])){
					$save = array();
					$save['purchase_id'] = $purchase_id;
					$save['product_id'] = $prod['product_id'];
					$save['unit_id'] = $prod['unit_id']; 
					$save['qty'] = $prod['qty'];
					$save['price'] = $prod['price'];
					$save['sal_price'] = $prod['sal_price'];
					$save['sal_unit_id'] = $prod['unit_id'];
					$save['amt'] = $prod['amt'];

					$id = $this->setting_model->save_setting('purchase_dtl',$save,true);

					$save = array();
					$save['bill_type'] = 'P'.$post['bill_type'];
					$save['bill_id'] = $purchase_id;
					$save['bill_date'] = $bill_date;
					$save['product_id'] = $prod['product_id'];														
					$save['pur_unit_id'] = $prod['unit_id']; 
					$save['pur_price'] = $prod['price'];
					$save['sal_unit_id'] = $prod['unit_id']; 
					$save['sal_price'] = $prod['sal_price'];

					if ($post['bill_type'] == 'R')
						$save['qty'] =-$prod['qty'];
					else
						$save['qty'] = $prod['qty'];

					$save['amt'] = $prod['amt'];
					$save['created_by'] = $this->session->userdata('admin_id');
					$save['created_date'] = time();		

					$id = $this->setting_model->save_setting('stock',$save,true);
				}					
			}

			if ($post['bill_type'] == 'R')
				$this->session->set_flashdata("alert_success","Purchase Return saved successfully!");			
			else
				$this->session->set_flashdata("alert_success","Purchase Bill saved successfully!");			

			redirect('purchase');							
		}		

		if($bill_type=='R')
			$bill_type_str='Purchase Return';
		else
			$bill_type_str='Purchase Bill';		

		if($purchase_id){
			$data['meta_title'] = 'Edit '.$bill_type_str;			

			$condition=array();
			$condition[]=array('name'=>'purchase_id','value'=>$purchase_id);		
			$data['purchase'] = $this->setting_model->get_setting('purchase',$condition);	

			$order[] = array('name'=>'purchase_dtl_id','value'=>'asc');				
			$data['purchase_dtl'] = $this->setting_model->get_setting('purchase_dtl',$condition,$order);	

			// echo "<pre>";print_r($data['purchase_dtl']);exit;
		}
		else{
			$data['meta_title'] = $bill_type_str;

			$purchase_id=0;
			$data['purchase']=$data['purchase_dtl']=array();
		}		

		$data['page_title'] = $data['meta_title'];		
		$data['breadcrumbs'][] = array('title'=>$data['meta_title'], 'href'=> "");			

		$data['bill_type']=$bill_type;
		$data['bill_type_str']=$bill_type_str;
		$data['purchase_id']=$purchase_id;

		$order=array();											
		$order[] = array('name'=>'name','value'=>'asc');        
		$condition=array();
		$data['products'] = $this->setting_model->get_setting('product',$condition,$order,true);
		$data['units'] = $this->setting_model->get_setting('unit',$condition,$order,true);
		$data['taxes'] = $this->setting_model->get_setting('tax',$condition,$order,true);

		$this->load->view('common/header',$data);
		$this->load->view('transaction/purchase',$data);
		$this->load->view('common/footer',$data);
	}
	function print_bill($bill_type=false,$bill_id=false,$aj_call=false){		
		$data['company'] = $this->setting_model->get_setting('company');

		$condition[] = array('name'=>'bill_type','value'=>$bill_type);
		$condition[] = array('name'=>'sales_id','value'=>$bill_id);		
		
		$join[] = array('table_name' => 'customer' ,'condition' => 'sales.customer_id=customer.customer_id' ,'join_type' => 'left'); 
		$join[] = array('table_name' => 'tax' ,'condition' => 'sales.tax_id=tax.tax_id' ,'join_type' => 'left'); 
		$select=array('sales_id','bill_no','bill_date','pay_type','tot_amt','tax_amt','bill_amt','customer.name as customer_name','customer.address as customer_address','tax.name as tax_name');
		$data['sales'] = $this->setting_model->get_setting('sales',$condition,false,false,$select,$join);	

		$order[] = array('name'=>'sales_dtl_id','value'=>'asc');				
		$condition=$join=array();
		$condition[] = array('name'=>'sales_id','value'=>$bill_id);		
		$select = array('sales_dtl.*','product.name as product_name','unit.name as unit_name');
		$join[] = array('table_name' => 'product' ,'condition' => 'sales_dtl.product_id=product.product_id' ,'join_type' => 'left'); 
		$join[] = array('table_name' => 'unit' ,'condition' => 'sales_dtl.unit_id=unit.unit_id' ,'join_type' => 'left'); 
		$data['sales_dtl'] = $this->setting_model->get_setting('sales_dtl',$condition,$order,false,$select,$join);

		//echo "<pre>";print_r($data);exit;
    if($aj_call)
		  echo $this->load->view('transaction/print_bill',$data,true);
    else
      $this->load->view('transaction/print_bill',$data);
	}
	function sales($bill_type=false,$sales_id=false){
		if($this->input->server('REQUEST_METHOD') === 'POST'){
			$post = $this->input->post();

			$bill_date = str_replace("/","-", $post['bill_date']);
			list($dy, $mn, $yr) = explode('-', $bill_date);
			$bill_date = mktime(0,0,0,$mn,$dy,$yr);

			$save['bill_no'] = $post['bill_no'];	
			$save['bill_type'] = $post['bill_type'];
			$save['bill_date'] = $bill_date;
			$save['pay_type'] = $post['pay_type'];
			$save['customer_id'] = $post['customer_id'];

			$save['tot_amt'] = $post['tot_amt'];	
			$save['tax_id'] = $post['tax_id'];	
			$save['tax_amt'] = $post['tax_amt'];
			$save['bill_amt'] = $post['bill_amt'];			

			if (!empty($post['sales_id'])){
				$save['sales_id'] = $post['sales_id'];
				$save['modified_by'] = $this->session->userdata('admin_id');
				$save['modified_date'] = time();
				$sales_id = $save['sales_id'];
				$this->setting_model->save_setting('sales',$save);

				$this->db->where('sales_id',$sales_id);
				$this->db->delete('sales_dtl');

				$this->db->where('bill_type','S'.$bill_type);
				$this->db->where('bill_id',$sales_id);
				$this->db->delete('stock');
			}
			else{
				$save['created_by'] = $this->session->userdata('admin_id');
				$save['created_date'] = time();	
				$sales_id = $this->setting_model->save_setting('sales',$save,true);
			}

			foreach ($post['prod'] as $key => $prod) {
				if (!empty($prod['amt'])){
					$save = array();
					$save['sales_id'] = $sales_id;
					$save['product_id'] = $prod['product_id'];
					$save['unit_id'] = $prod['unit_id']; 
					$save['qty'] = $prod['qty'];							
					$save['price'] = $prod['price'];		

					$pur_price = explode('/', $prod['pur_price']);
					$save['pur_price'] = $pur_price['0'];
					$save['pur_unit_id'] = $pur_price['1'];
					$save['amt'] = $prod['amt'];
					$id = $this->setting_model->save_setting('sales_dtl',$save,true);

					$save = array();
					$save['bill_type'] = 'S'.$post['bill_type'];
					$save['bill_id'] = $sales_id;
					$save['bill_date'] = $bill_date;
					$save['product_id'] = $prod['product_id'];														
					$save['sal_unit_id'] = $prod['unit_id']; 
					$save['sal_price'] = $prod['price'];
					$save['pur_unit_id'] =$pur_price['1'];
					$save['pur_price'] = $pur_price['0'];							

					if ($post['bill_type'] == 'R')
						$save['qty'] = $prod['qty'];
					else
						$save['qty'] = -$prod['qty'];

					$save['amt'] = $prod['amt'];
					$save['created_by'] = $this->session->userdata('admin_id');
					$save['created_date'] = time();		

					$id = $this->setting_model->save_setting('stock',$save,true);
				}					
			}

			if ($post['bill_type'] == 'R')
				$this->session->set_flashdata("alert_success","Sales Return saved successfully!");			
			else
				$this->session->set_flashdata("alert_success","Sales Bill saved successfully!");			

      if(!empty($post['print_bill'])){
        $this->print_bill($post['bill_type'],$sales_id,true);        
        exit;
      }
      else
       redirect('sales');   
   }		

   if($bill_type=='R')
     $bill_type_str='Sales Return';
   else
     $bill_type_str='Sales Bill';

   if($sales_id){
     $data['meta_title'] = 'Edit '.$bill_type_str;

     $condition=array();
     $condition[]=array('name'=>'sales_id','value'=>$sales_id);		
     $data['sales'] = $this->setting_model->get_setting('sales',$condition);	

     $order[] = array('name'=>'sales_dtl_id','value'=>'asc');				
     $data['sales_dtl'] = $this->setting_model->get_setting('sales_dtl',$condition,$order);	

			// echo "<pre>";print_r($data['purchase_dtl']);exit;
   }
   else{
     $data['meta_title'] = $bill_type_str;

     $sales_id=0;
     $data['sales']=$data['sales_dtl']=array();
   }

   $data['page_title'] = $data['meta_title'];		
   $data['breadcrumbs'][] = array('title'=>$data['meta_title'], 'href'=> "");			

   $data['bill_type']=$bill_type;
   $data['bill_type_str']=$bill_type_str;
   $data['sales_id']=$sales_id;

   $order=array();											
   $order[] = array('name'=>'name','value'=>'asc');        
   $condition=array();
   $data['products'] = $this->setting_model->get_setting('product',$condition,$order,true);
   $data['units'] = $this->setting_model->get_setting('unit',$condition,$order,true);
   $data['taxes'] = $this->setting_model->get_setting('tax',$condition,$order,true);

   $this->load->view('common/header',$data);
   $this->load->view('transaction/sales',$data);
   $this->load->view('common/footer',$data);
 }
 function get_pur_prices($product_id){
  $select=array('purchase_dtl.price','purchase_dtl.sal_price','purchase_dtl.unit_id','unit.name as unit_name');
  $condition[] = array('name'=>'product_id','value'=>$product_id);
  $order[] = array('name'=>'purchase_dtl_id','value'=>'asc');        
  $join[] = array('table_name' => 'unit' ,'condition' => 'unit.unit_id =purchase_dtl.unit_id' ,'join_type' => 'left'); 
  $res = $this->setting_model->get_setting('purchase_dtl',$condition,$order,false,$select,$join);

  $resp='<option value="0">-</option>';
  if(!empty($res)){
   foreach($res as $res1){ 
    $resp .= '<option data-unit-id="'.$res1["unit_id"].'" data-sal-price="'.$res1["sal_price"].'" value="'.$res1["price"].'/'.$res1["unit_id"].'">₹'.number_format($res1["price"], 2).' / '.$res1["unit_name"].' (Sal. ₹'.number_format($res1["sal_price"], 2).')</option>';
  } 
}

echo($resp);
}
}
?>