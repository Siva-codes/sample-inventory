	<?php 

	Class Report extends AdminController
	{
		function purchase($bill_type){
			if($bill_type=='R')
				$bill_type_str='Purchase Return';
			else
				$bill_type_str='Purchase Bill';

			$data['meta_title'] = $bill_type_str." Report";
			$data['page_title'] = $bill_type_str." Report";
			$data['breadcrumbs'][] = array('title'=>$bill_type_str." Report", 'href'=> "");			

			$data['bill_type']=$bill_type;
			$data['bill_type_str']=$bill_type_str;
			
			$condition=array();
			$condition[]=array('name'=>'bill_type','value'=>$bill_type);		
			$order[] = array('name'=>'purchase_id','value'=>'desc');				
			$join[] = array('table_name' => 'supplier' ,'condition' => 'purchase.supplier_id=supplier.supplier_id' ,'join_type' => 'left'); 
			$join[] = array('table_name' => 'tax' ,'condition' => 'purchase.tax_id=tax.tax_id' ,'join_type' => 'left'); 
			$select=array('purchase_id','bill_no','bill_date','pay_type','tot_amt','tax_amt','bill_amt','supplier.name as supplier_name','tax.name as tax_name');

			$data['data_hdrs'] = array('Bill No','Bill Date','Supplier','Pay Type','Tot.Amt','Tax','Tax Amt','Nett Amt');
			$data['data_cols'] = array('bill_no','bill_date','supplier_name','pay_type','tot_amt','tax_name','tax_amt','bill_amt');
			$data['tbl_hdr_widths'] = array('name','name','name','name','name','name','name','action');			

			$data['data_hdrs'][] ='Action';
			$data['data_cols'][] ='action';
			$data['tbl_hdr_widths'][] ='action';		

			$data['recs'] = $this->setting_model->get_setting('purchase',$condition,$order,false,$select,$join);	

			$this->load->view('common/header',$data);
			$this->load->view('report/purchase',$data);
			$this->load->view('common/footer',$data);
		}
		function sales($bill_type){
			if($bill_type=='R')
				$bill_type_str='Sales Return';
			else
				$bill_type_str='Sales Bill';

			$data['meta_title'] = $bill_type_str." Report";
			$data['page_title'] = $bill_type_str." Report";
			$data['breadcrumbs'][] = array('title'=>$bill_type_str." Report", 'href'=> "");			

			$data['bill_type']=$bill_type;
			$data['bill_type_str']=$bill_type_str;
			
			$condition=array();
			$condition[]=array('name'=>'bill_type','value'=>$bill_type);		
			$order[] = array('name'=>'sales_id','value'=>'desc');				
			$join[] = array('table_name' => 'customer' ,'condition' => 'sales.customer_id=customer.customer_id' ,'join_type' => 'left'); 
			$join[] = array('table_name' => 'tax' ,'condition' => 'sales.tax_id=tax.tax_id' ,'join_type' => 'left'); 
			$select=array('sales_id','bill_no','bill_date','pay_type','tot_amt','tax_amt','bill_amt','customer.name as customer_name','tax.name as tax_name');

			$data['data_hdrs'] = array('Bill No','Bill Date','Customer','Pay Type','Tot.Amt','Tax','Tax Amt','Nett Amt');
			$data['data_cols'] = array('bill_no','bill_date','customer_name','pay_type','tot_amt','tax_name','tax_amt','bill_amt');
			$data['tbl_hdr_widths'] = array('name','name','name','name','name','name','name','name');			

			$data['data_hdrs'][] ='Action';
			$data['data_cols'][] ='action';
			$data['tbl_hdr_widths'][] ='action';		

			$data['recs'] = $this->setting_model->get_setting('sales',$condition,$order,false,$select,$join);	

			$this->load->view('common/header',$data);
			$this->load->view('report/sales',$data);
			$this->load->view('common/footer',$data);
		}
		function get_min_unit($unit_id,$qty){		
			// if($unit_id==3 && $qty <0)
			// 	$t=1;
			// else
			// 	$t=0;

			$exists=1;
			$unit_ids=$unit_id;
			while ($exists==1) {
				$condition=array();
				$condition[]=array('name'=>'unit_id','value'=>$unit_id);
				$select=array('parent_unit_id','conversion');
				$res= $this->setting_model->get_setting('unit',$condition,false,false,$select);	
				if(!empty($res)){
					if(!empty($res['conversion'])){
						$qty=(double)$res['conversion']*$qty;
						$unit_id = $res['parent_unit_id'];

						$min_unit_qty[0]=$unit_id;
						$min_unit_qty[1]=$qty;	

						// if($t==1){
						// 	echo "<pre>";print_r($min_unit_qty);
						// }
					}
					else{
						$min_unit_qty[0]=$unit_id;
						$min_unit_qty[1]=$qty;						
						$exists=0;						
					}

					$unit_ids=$unit_ids.','.$unit_id;
				}	
			}

			// if($t==1){
			// 	echo "<pre>";print_r($min_unit_qty);exit;
			// }

			$min_unit_qty[2]=$unit_ids;
			return $min_unit_qty;
		}
		function get_conv_unit($unit_id,$qty,$unit_ids){	
			// $min_unit_id=$unit_id;
			// $tot_qty=$qty;	
			$conv_unit_qty=array();
			// $conv_unit_qty[0]=''
			// $chk=0;
			// if($qty==3){
			// 	$chk=1;
			// }
			$exists=1;
			while ($exists==1) {
				$condition=array();
				$condition[]=array('name'=>'parent_unit_id','value'=>$unit_id);
				$condition[] = array('name'=>'$','value'=>"unit_id in($unit_ids)");			
				$select=array('unit_id','conversion','parent_unit_id');
				$res= $this->setting_model->get_setting('unit',$condition,false,false,$select);	
				if(!empty($res)){
					if(!empty($res['parent_unit_id'])){
						if($qty>(double)$res['conversion']){
							$qty=$qty/(double)$res['conversion'];
							$unit_id = $res['unit_id'];

							$conv_unit_qty[0]=$unit_id;
							$conv_unit_qty[1]=$qty;					
						}
						else{
							$conv_unit_qty[0]=$unit_id;
							$conv_unit_qty[1]=$qty;					
							$exists=0;	
						}
					}
					else{
						$conv_unit_qty[0]=$unit_id;
						$conv_unit_qty[1]=$qty;						
						$exists=0;
					}
				}
				else{
					$conv_unit_qty[0]=$unit_id;
					$conv_unit_qty[1]=$qty;						
					$exists=0;
				}
			}


			// $condition=array();
			// $condition[]=array('name'=>'unit_id','value'=>$min_unit_qty[0]);
			// $select=array('name');
			// $res= $this->setting_model->get_setting('unit',$condition,false,false,$select);	
			// $min_unit_qty[0] = $res['name'];

			// if($min_unit_id==3 ){
			// 	echo "<pre>";print_r($tot_qty);exit;
			// }
			return $conv_unit_qty;
		}
		function stock(){
			$data['meta_title'] = "Stock Report";
			$data['page_title'] = "Stock Report";
			$data['breadcrumbs'][] = array('title'=>"Stock Report", 'href'=> "");			

			$stock=array(); //prodname, pur price, grm, 60000(pur qty),0(sal qty), 60000(tot.qty),units
			$select=array('stock.product_id','product.name as product_name');
			$condition=$order=$group=array();
			$order[] = array('name'=>'product_name','value'=>'asc');
			$group[] = array('value'=>'stock.product_id');
			$join[] = array('table_name' => 'product' ,'condition' => 'product.product_id =stock.product_id' ,'join_type' => 'left'); 
			$prods= $this->setting_model->get_setting('stock',$condition,$order,false,$select,$join,$group);	
			if(!empty($prods)){			
				$order=$group=array();
				$select=array('sum(qty) as tot_qty','pur_unit_id','sal_unit_id','pur_price');
				$order[] = array('name'=>'pur_price','value'=>'asc');
				$group[] = array('value'=>'pur_unit_id');
				$group[] = array('value'=>'pur_price');		

				foreach ($prods as $prod) {								
					$condition=array();
					$condition[]=array('name'=>'product_id','value'=>$prod['product_id']);		
					$condition[] = array('name'=>'$','value'=>"bill_type in('PB','PR')");					
					$pur_prods= $this->setting_model->get_setting('stock',$condition,$order,false,$select,false,$group);	
					if(!empty($pur_prods)){					
						foreach ($pur_prods as $pur_prod) {
							$min_unit_qty=$this->get_min_unit($pur_prod['pur_unit_id'],$pur_prod['tot_qty']);

							$exists=0;
							if(!empty($stock)){					
								foreach ($stock as $key => $stk) {
									if($stk[0]==$prod['product_name'] &&$stk[1]==$pur_prod['pur_price'] &&$stk[2]==$min_unit_qty[0]){
										$stock[$key][3]=(double)$stock[$key][3]+(double)$min_unit_qty[1];
										$stock[$key][5]=(double)$stock[$key][5]+(double)$min_unit_qty[1];
										$exists=1;
										break;
									}
								}
							}

							if($exists==0)
								$stock[]=array($prod['product_name'],$pur_prod['pur_price'],$min_unit_qty[0],$min_unit_qty[1],0,$min_unit_qty[1],$min_unit_qty[2]);
						}
					}

					$condition=array();
					$condition[]=array('name'=>'product_id','value'=>$prod['product_id']);		
					$condition[] = array('name'=>'$','value'=>"bill_type in('SB','SR')");
					$sal_prods= $this->setting_model->get_setting('stock',$condition,$order,false,$select,false,$group);	
					if(!empty($sal_prods)){					
						foreach ($sal_prods as $sal_prod) {
							$min_unit_qty=$this->get_min_unit($sal_prod['sal_unit_id'],$sal_prod['tot_qty']);

							$exists=0;
							if(!empty($stock)){					
								foreach ($stock as $key => $stk) {
									if($stk[0]==$prod['product_name'] &&$stk[1]==$sal_prod['pur_price'] &&$stk[2]==$min_unit_qty[0]){
										$stock[$key][4]=(double)$stock[$key][4]+(double)$min_unit_qty[1];
										$stock[$key][5]=(double)$stock[$key][5]+(double)$min_unit_qty[1];
										$exists=1;
										break;
									}
								}
							}

							if($exists==0)
								$stock[]=array($prod['product_name'],$sal_prod['pur_price'],$min_unit_qty[0],0,$min_unit_qty[1],$min_unit_qty[1],$min_unit_qty[2]);
						}
					}
				}
			}

			// echo "<pre>";print_r($stock);exit;

			if(!empty($stock)){					
				foreach ($stock as $key => $stk) {
					$tot_pur_qty=$this->get_conv_unit($stk[2],$stk[3],$stk[6]);
					$condition=array();
					$condition[]=array('name'=>'unit_id','value'=>$tot_pur_qty[0]);
					$select=array('name');
					$res= $this->setting_model->get_setting('unit',$condition,false,false,$select);					

					if($tot_pur_qty[1]!=0)
						$stock[$key][3]=$tot_pur_qty[1].' ('.$res['name'].')';
					else
						$stock[$key][3]=0;

					$tot_sal_qty=$this->get_conv_unit($stk[2],abs($stk[4]),$stk[6]);
					$condition=array();
					$condition[]=array('name'=>'unit_id','value'=>$tot_sal_qty[0]);
					$select=array('name');
					$res= $this->setting_model->get_setting('unit',$condition,false,false,$select);

					if($tot_sal_qty[1]!=0)
						$stock[$key][4]=abs($tot_sal_qty[1]).' ('.$res['name'].')';
					else
						$stock[$key][4]=0;					

					// echo "<pre>";print_r($stk);

					$tot_qty=$this->get_conv_unit($stk[2],$stk[5],$stk[6]);


					if(strpos($tot_qty[1],'.')!== false){
						$val =number_format((double)$tot_qty[1], 2, '.', '');
						$tot_qty1= explode('.', $val);
					}
					else
						$tot_qty1=0;

					//echo "<pre>";print_r($tot_qty1);
					$condition=array();
					$condition[]=array('name'=>'unit_id','value'=>$tot_qty[0]);
					$select=array('name','parent_unit_id','conversion');
					$res= $this->setting_model->get_setting('unit',$condition,false,false,$select);

					if($tot_qty[1]!=0)
						$stock[$key][5]=$tot_qty[1].' ('.$res['name'].')';
					else
						$stock[$key][5]=0;		

					if(!empty($tot_qty1) && isset($tot_qty1[1])){
						$condition=array();
						$condition[]=array('name'=>'unit_id','value'=>$res['parent_unit_id']);
						$select=array('name');
						$res1= $this->setting_model->get_setting('unit',$condition,false,false,$select);
						$val=$tot_qty1[1]/100*(double)$res['conversion'];
						$stock[$key][5]=$tot_qty1[0].' ('.$res['name'].') '.(int)$val.' ('.$res1['name'].')';
					}

					unset($stock[$key][2]);
					unset($stock[$key][6]);
				}
			}
			//exit;
			$data['recs']=$stock;

			$data['data_hdrs'] = array('Product','Purchase Price','Purchase','Sales','Stock');
			$data['data_cols'] = array('0','1','3','4','5');
			$data['tbl_hdr_widths'] = array('name','name','name','name','name');			

			$this->load->view('common/header',$data);
			$this->load->view('report/stock',$data);
			$this->load->view('common/footer',$data);
		}
	}
	?>