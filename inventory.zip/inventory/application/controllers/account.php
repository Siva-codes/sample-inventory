<?php 

Class Account extends AdminController
{
	function __construct(){
		parent::__construct();
	}
	
	function login()
	{
		if(isset($_GET['email']) && isset($_GET['password']))
		{
			$email = $_GET['email'];
			$password = $_GET['password'];

			$condition[] = array('name'=>'email','value'=>$email);
			$condition[] = array('name'=>'password','value'=>md5($password));
			$res = $this->setting_model->get_setting('admin',$condition,false,true);
     // echo $this->db->last_query();exit();
			if(!empty($res)){
				$this->session->set_userdata("admin_id",$res['admin_id']);

				if($this->session->userdata('admin_redirect_link')){
					$redirect_link = $this->session->userdata('admin_redirect_link');
					$this->session->unset_userdata('admin_redirect_link');
					// redirect($redirect_link);
					echo $redirect_link;
					exit;
				}
				
				// redirect('account/dashboard');
				echo site_url('dashboard');
				exit;
			}else{
				 // $this->session->set_flashdata("alert_error","Invalid User name or Password!");
				// redirect('account/login');			
				echo "E";
				exit;
			}
		}

		$data['meta_title'] = 'Login';
		$this->load->view('account/login',$data);
	}
	
	function logout()
	{
		$this->session->unset_userdata("admin_id");
		redirect('login');
	}

	function dashboard()
	{
		if(!empty($this->session->userdata("admin_id"))){
			$data['meta_title'] = 'Dashboard';

			$tots=$overview1=$overview2=array();			

			$tot_pur=$tot_pur_ret=$tot_sal=$tot_sal_ret=0;
			
			$select =array("sum(bill_amt) as tot_amt");
			$condition[] = array('name'=>'bill_type','value'=>'B');				
			$res = $this->setting_model->get_setting('sales',$condition,false,false,$select);
			if(!empty($res))
				$tot_sal=$res['tot_amt'];

			$condition=array();
			$condition[] = array('name'=>'bill_type','value'=>'R');				
			$res = $this->setting_model->get_setting('sales',$condition,false,false,$select);
			if(!empty($res))
				$tot_sal_ret=$res['tot_amt'];

			$tots[0]=$tot_sal-$tot_sal_ret;	

			$condition=array();
			$select =array("sum(bill_amt) as tot_amt");
			$condition[] = array('name'=>'bill_type','value'=>'B');				
			$res = $this->setting_model->get_setting('purchase',$condition,false,false,$select);
			if(!empty($res))
				$tot_pur=$res['tot_amt'];

			$condition=array();
			$condition[] = array('name'=>'bill_type','value'=>'R');				
			$res = $this->setting_model->get_setting('purchase',$condition,false,false,$select);
			if(!empty($res))
				$tot_pur_ret=$res['tot_amt'];

			$tots[1]=$tot_pur-$tot_pur_ret;	

			$select =array("count(*) as tot_rec");
			$res = $this->setting_model->get_setting('product_category',false,false,false,$select);
			if(!empty($res))
				$tots[2]=$res['tot_rec'];
			else
				$tots[2]=0;

			$select =array("count(*) as tot_rec");
			$res = $this->setting_model->get_setting('product',false,false,false,$select);
			if(!empty($res))
				$tots[3]=$res['tot_rec'];
			else
				$tots[3]=0;

			$data['tots']=$tots;

			$overview1[0]=$tot_pur;
			$overview1[1]=$tot_pur_ret;

			$condition=array();
			$select =array("count(*) as tot_rec");
			$condition[] = array('name'=>'bill_type','value'=>'B');				
			$res = $this->setting_model->get_setting('purchase',$condition,false,false,$select);
			if(!empty($res))
				$overview1[2]=$res['tot_rec'];
			else
				$overview1[2]=0;

			$condition=array();
			$select =array("count(*) as tot_rec");
			$condition[] = array('name'=>'bill_type','value'=>'R');				
			$res = $this->setting_model->get_setting('purchase',$condition,false,false,$select);
			if(!empty($res))
				$overview1[3]=$res['tot_rec'];
			else
				$overview1[3]=0;

			$overview2[0]=$tot_sal;
			$overview2[1]=$tot_sal_ret;

			$condition=array();
			$select =array("count(*) as tot_rec");
			$condition[] = array('name'=>'bill_type','value'=>'B');				
			$res = $this->setting_model->get_setting('sales',$condition,false,false,$select);
			if(!empty($res))
				$overview2[2]=$res['tot_rec'];
			else
				$overview2[2]=0;

			$condition=array();
			$select =array("count(*) as tot_rec");
			$condition[] = array('name'=>'bill_type','value'=>'R');				
			$res = $this->setting_model->get_setting('sales',$condition,false,false,$select);
			if(!empty($res))
				$overview2[3]=$res['tot_rec'];
			else
				$overview2[3]=0;

			$data['overview1']=$overview1;
			$data['overview2']=$overview2;

			$this->load->view('common/header',$data);
			$this->load->view('common/dashboard',$data);
			$this->load->view('common/footer',$data);	
		}		
	}

	function profile()
	{
		// echo $this->session->userdata("admin_id");exit;
		if($this->input->server('REQUEST_METHOD') === 'POST')
		{
			$save['admin_id'] = $this->session->userdata("admin_id");
			if (($this->input->post('email'))){
				$save['email'] = $this->input->post('email');
				$save['password'] = md5($this->input->post('password'));
			}			

			if (($this->input->post('name')))
				$save['name'] = $this->input->post('name');

			// if (isset($this->input->post('email_id')))
			// 	$save['email_id'] = $this->input->post('email_id');
			$err=0;
			if(!empty($_FILES['img']['name'])){
				$upload_path = ADMIN_USER_IMG_PATH. $this->session->userdata("admin_id");

				if(!file_exists($upload_path))
					mkdir($upload_path, 0777, true);

				$config['upload_path'] = $upload_path;
				$config['allowed_types'] = 'jpg|png|jpeg';
				$config['max_size']	= '100';
				$config['max_width']  = '700';
				$config['max_height']  = '700';
				$this->load->library('upload', $config);
				
				if ( ! $this->upload->do_upload('img')){
					$err=1;
					$this->session->set_flashdata("alert_error",$this->upload->display_errors());
				}else{
					$image_info = $this->upload->data();
					// resize_image($image_info['file_name'], $upload_path, admin_IMG_SIZE );
					$save['img'] = $image_info['file_name'];
				}
			}

			$this->setting_model->save_setting('admin',$save);

			if($err==0)
				$this->session->set_flashdata("alert_success","Changes saved Successfully!");

			redirect('profile');
		}

		$data['meta_title'] = 'My Profile';

		$admin_id = $this->session->userdata("admin_id");

		$condition = array();
		$condition[] = array('name'=>'admin_id','value'=>$admin_id);
		$data['user_info'] = $this->setting_model->get_setting('admin',$condition);
		//echo "<pre>";print_r(ADMIN_USER_IMG_PATH.$data['user_info']['admin_id'].'/'.$data['user_info']['img']);exit;
		if(!empty($data['user_info']['img']))
			$data['user_img'] = base_url(ADMIN_USER_IMG_PATH.$data['user_info']['admin_id'].'/'.$data['user_info']['img']);
		else
			$data['user_img'] = base_url('assets/img/admin.jpg');

		$this->load->view('common/header',$data);
		$this->load->view('account/profile',$data);
		$this->load->view('common/footer',$data);	
	}
}

?>