<?php 

Class Aj_data_dashboard extends AdminController
{
	function index(){
		$action = $_GET['action'];

		switch ($action) {
			case 'get_pur_chart':{
				$query_filter = array();

				$query_filter['from_date'] = mktime(0, 0, 0, date("m")-5, 1);
				$query_filter['to_date'] = time();

				$fr_date= date('FY', $query_filter['from_date']);

				$order = array();
				$group = array();
				$condition=array();
				$select =array("sum(bill_amt) as tot_amt",'concat(MONTHNAME(FROM_UNIXTIME(bill_date)), YEAR(FROM_UNIXTIME(bill_date))) as mon');
				$order[] = array('name'=>'purchase.bill_date','value'=>'asc'); 		
				$group[] = array('value'=>'mon');

				$condition[] = array('name'=>'bill_type','value'=>'B');				
				$res = $this->setting_model->get_setting_list('purchase',$condition,$order,$query_filter,false,false,$select,false,$group);		

				$result1 = array();
				$result2 = array();				
				$date = $fr_date;
				for ($count=1; $count <=6; $count++) { 					
					$exists=false;
					if ($res){
						foreach ($res as $key => $res1){
							if($res1['mon']==$date){
								$result1[] = array("label" =>  $res1['mon'],"y" =>  (double)$res1['tot_amt']);
								$exists=true;
								break;
							}
						}
					}
					
					if(!$exists){
						$result1[] = array("label" =>  $date,"y" =>0);
					}

					$date = date("FY", strtotime("+1 month", strtotime($date)));
				}

				$condition=array();
				$condition[] = array('name'=>'bill_type','value'=>'R');
				$res = $this->setting_model->get_setting_list('purchase',$condition,$order,$query_filter,false,false,$select,false,$group);		
				// $result2 = array();
				// if ($res){
				// 	foreach ($res as $key => $res1){
				// 		$result2[] = array("label" =>  $res1['mon'],"y" =>  (int)$res1['tot_amt']);
				// 	}
				// }
				$date = $fr_date;
				for ($count=1; $count <=6; $count++) { 					
					$exists=false;
					if ($res){
						foreach ($res as $key => $res2){
							if($res2['mon']==$date){
								$result2[] = array("label" =>  $res2['mon'],"y" =>  (double)$res2['tot_amt']);
								$exists=true;
								break;
							}
						}
					}
					
					if(!$exists){
						$result2[] = array("label" =>  $date,"y" =>0);
					}

					$date = date("FY", strtotime("+1 month", strtotime($date)));
				}	

				echo json_encode(array("a" => $result1, "b" => $result2));
				break; 
			}
			case 'get_sal_chart':{
				$query_filter = array();

				$query_filter['from_date'] = mktime(0, 0, 0, date("m")-5, 1);
				$query_filter['to_date'] = time();

				$fr_date= date('FY', $query_filter['from_date']);

				$order = array();
				$group = array();
				$condition=array();
				$select =array("sum(bill_amt) as tot_amt",'concat(MONTHNAME(FROM_UNIXTIME(bill_date)), YEAR(FROM_UNIXTIME(bill_date))) as mon');
				$order[] = array('name'=>'sales.bill_date','value'=>'asc'); 		
				$group[] = array('value'=>'mon');

				$condition[] = array('name'=>'bill_type','value'=>'B');				
				$res = $this->setting_model->get_setting_list('sales',$condition,$order,$query_filter,false,false,$select,false,$group);		

				$result1 = array();
				$result2 = array();				
				$date = $fr_date;
				for ($count=1; $count <=6; $count++) { 					
					$exists=false;
					if ($res){
						foreach ($res as $key => $res1){
							if($res1['mon']==$date){
								$result1[] = array("label" =>  $res1['mon'],"y" =>  (double)$res1['tot_amt']);
								$exists=true;
								break;
							}
						}
					}
					
					if(!$exists){
						$result1[] = array("label" =>  $date,"y" =>0);
					}

					$date = date("FY", strtotime("+1 month", strtotime($date)));
				}

				$condition=array();
				$condition[] = array('name'=>'bill_type','value'=>'R');
				$res = $this->setting_model->get_setting_list('sales',$condition,$order,$query_filter,false,false,$select,false,$group);		
				$date = $fr_date;
				for ($count=1; $count <=6; $count++) { 					
					$exists=false;
					if ($res){
						foreach ($res as $key => $res2){
							if($res2['mon']==$date){
								$result2[] = array("label" =>  $res2['mon'],"y" =>  (double)$res2['tot_amt']);
								$exists=true;
								break;
							}
						}
					}
					
					if(!$exists){
						$result2[] = array("label" =>  $date,"y" =>0);
					}

					$date = date("FY", strtotime("+1 month", strtotime($date)));
				}	

				echo json_encode(array("a" => $result1, "b" => $result2));
				break; 
			}
			case 'get_rec_sals':{
				$condition=array();
				$condition[]=array('name'=>'bill_type','value'=>'B');		
				$order[] = array('name'=>'sales_id','value'=>'desc');			
				$query_filter['start']=0;
				$query_filter['limit']= 10;					
				$join[] = array('table_name' => 'customer' ,'condition' => 'sales.customer_id=customer.customer_id' ,'join_type' => 'left'); 
				$join[] = array('table_name' => 'tax' ,'condition' => 'sales.tax_id=tax.tax_id' ,'join_type' => 'left'); 
				$select=array('sales_id','bill_no','bill_date','pay_type','tot_amt','tax_amt','bill_amt','customer.name as customer_name','tax.name as tax_name');

				$res = $this->setting_model->get_setting_list('sales',$condition,$order,$query_filter,false,false,$select,$join);
				$html='';
				if(!empty($res)){
					$html='<table class="table table-hover mb-0"><tbody>';
					$html.='<thead><tr><th class="th-sno sorting" tabindex="0" aria-controls="data_table" rowspan="1" colspan="1" style="width: 32px;" aria-label="SNo.: activate to sort column ascending">SNo.</th><th class="th-name sorting" tabindex="0" aria-controls="data_table" rowspan="1" colspan="1" style="width: 105px;" aria-label="Bill No: activate to sort column ascending">Bill No</th><th class="th-name sorting" tabindex="0" aria-controls="data_table" rowspan="1" colspan="1" style="width: 114px;" aria-label="Bill Date: activate to sort column ascending">Bill Date</th><th class="th-name sorting" tabindex="0" aria-controls="data_table" rowspan="1" colspan="1" style="width: 139px;" aria-label="Customer: activate to sort column ascending">Customer</th><th class="th-name sorting" tabindex="0" aria-controls="data_table" rowspan="1" colspan="1" style="width: 114px;" aria-label="Pay Type: activate to sort column ascending">Pay Type</th><th class="th-name sorting" tabindex="0" aria-controls="data_table" rowspan="1" colspan="1" style="width: 131px;" aria-label="Tot.Amt: activate to sort column ascending">Tot.Amt</th><th class="th-name sorting" tabindex="0" aria-controls="data_table" rowspan="1" colspan="1" style="width: 108px;" aria-label="Tax: activate to sort column ascending">Tax</th><th class="th-name sorting" tabindex="0" aria-controls="data_table" rowspan="1" colspan="1" style="width: 112px;" aria-label="Tax Amt: activate to sort column ascending">Tax Amt</th><th class="th-name sorting" tabindex="0" aria-controls="data_table" rowspan="1" colspan="1" style="width: 113px;" aria-label="Nett Amt: activate to sort column ascending">Nett Amt</th></tr></thead>';
					foreach ($res as $key => $res1) {
						if($res1['pay_type']=='CA')
							$pay_type = 'Cash';
						else
							$pay_type = 'Credit';

						$html.='<tr>';
						$html.='<td>'.($key+1).'</td>';
						$html.='<td>'.$res1['bill_no'].'</td>';
						$html.='<td>'.date("d-m-Y", $res1['bill_date']).'</td>';
						$html.='<td>'.$res1['customer_name'].'</td>';
						$html.='<td>'.$pay_type.'</td>';
						$html.='<td>'.number_format($res1['tot_amt'],2).'</td>';
						$html.='<td>'.$res1['tax_name'].'</td>';
						$html.='<td>'.number_format($res1['tax_amt'],2).'</td>';
						$html.='<td>'.number_format($res1['bill_amt'],2).'</td>';
						$html.='</tr>';
					}
					$html.='</tbody></table>';
				}
				echo $html;				
				break; 
			}

		}
	}
}
?>