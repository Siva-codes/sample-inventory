<?php

class setting_model extends CI_Model
{
	function check_setting($setting_type,$setting_id,$setting_str)
	{
		switch ($setting_type) {
			case 'product_category':
			$exists = 0;
			$condition = array();
			$condition[] = array('name'=>$setting_type.'_id','value'=> $setting_id);

			$res = $this->get_setting("product",$condition);
			if (!empty($res)){
				$exists = 1;
				return 'This '.$setting_str.' is used in Product entry, could not be deleted!';
			}				

			break;			 
			default:
		}

		return "1";
	}
	function get_setting($table_name,$condition=false,$order=false,$active= false,$select = false,$join=false,$group=false,$showqry=false)
	{
		if ($active){
      $this->db->where('('.$table_name.".status='1' or ".$table_name.".status='A')"); 
			// $this->db->where($table_name.'.status',1);
			// $this->db->or_where($table_name.'.status','A');
		}

		if ($select){
			$this->db->select($select);
		}

		if ($join){
		//	echo"<pre>";print_r($join);exit();

			foreach ($join as $key => $jn) {
				$this->db->join($jn['table_name'],$jn['condition'],$jn['join_type']);
			}			
		}

		if ($group){
			foreach ($group as $key => $grp) {
				$this->db->group_by($grp['value']);
			}			
		}
		if ($condition){
			// print_r($condition);exit();
			foreach ($condition as $key => $cond) {
				if (!empty($cond['name'])){
					if ($cond['name'] == 'like' || $cond['name'] == '$'){
						$this->db->where($cond['value']);	
						 //echo $cond['value'];					exit();
					}
					else
						$this->db->where($cond['name'],$cond['value']);						
				}
			}
		}

		if ($order){
			foreach ($order as $key => $ord) {
				if (!empty($ord['name'])){
					$this->db->order_by($ord['name'],$ord['value']);						
				}
			}
			$query = $this->db->get($table_name);
			// if ($group && $table_name =='appliance'){
			 	// echo $this->db->last_query();exit();
			// }
			// if ($table_name =='online_est_appl1'){
			// 	echo $this->db->last_query();exit();
			// }
			  //  if ($showqry){
			  // echo $this->db->last_query();exit();
		   //  }
			return $query->result_array();
		}
		else{
			$query = $this->db->get($table_name);
			 // if ($table_name =='product'){
			  	// echo $this->db->last_query();exit();}

			// echo $this->db->last_query();exit();
			
			  //  if ($showqry){
			  // echo $this->db->last_query();exit();
		   //    }
			return $query->num_rows()?$query->row_array():false;
		}		
	}	

	function get_setting_list($table_names,$condition=false,$order=false,$filter=false,$total=false,$active= false,$select = false,$join=false,$group=false,$showqry=false)
	{
		if (is_array($table_names)){
			$table_name = $table_names[0]['value'];
			$table_name1 = $table_names[1]['value'];
		}
		else{
			$table_name = $table_names;
			$table_name1 ='';
		}

		if ($group){
			foreach ($group as $key => $grp) {
				$this->db->group_by($grp['value']);
			}			
		}
		if ($total){
			$this->db->select(array($table_name.'.status'));

			if ($condition){
				foreach ($condition as $key => $cond) {
					if (!empty($cond['name'])){
						if ($cond['name'] == 'like' || $cond['name'] == '$'){
							$this->db->where($cond['value']);	
						}
						elseif ($cond['name'] == 'having')
							$this->db->having($cond['value']);			
						else
							$this->db->where($cond['name'],$cond['value']);			
					}
				}
			}

			if ($select){
				$this->db->select($select);
			}

			if ($join){				
				foreach ($join as $key => $jn) {
					$this->db->join($jn['table_name'],$jn['condition'],$jn['join_type']);
				}			
			}

			if(!empty($filter['filter_name'])){
				$this->db->like($filter['filter_name']['name'],$filter['filter_name']['value']);
			}

			if (!empty($filter['from_date'])){
				if ($table_name =='bill' || $table_name =='other_exp')
					$this->db->where($table_name.'.bill_date >=',$filter['from_date']);
				else
					$this->db->where($table_name.'.created_date >=',$filter['from_date']);
			}

			if (!empty($filter['to_date'])){
				if ($table_name =='bill' || $table_name =='other_exp')
					$this->db->where($table_name.'.bill_date <=',$filter['to_date']);
				else
					$this->db->where($table_name.'.created_date <=',$filter['to_date']);
			}

			if (!empty($filter['mod_from_date'])){
				$this->db->where($table_name.'.created_date >=',$filter['mod_from_date']);
			}

			if (!empty($filter['mod_to_date'])){
				$this->db->where($table_name.'.created_date <=',$filter['mod_to_date']);
			}

			if ($active){
				$this->db->where('('.$table_name.".status='1' or ".$table_name.".status='A')"); 
			}

			$results = $this->db->get($table_name)->num_rows();
		}
		else{
			if ($select){
				$this->db->select($select);
			}

			if ($join){
				foreach ($join as $key => $jn) {
					$this->db->join($jn['table_name'],$jn['condition'],$jn['join_type']);
				}			
			}

			if(!empty($filter['limit'])){
				$this->db->limit($filter['limit'], $filter['start']);		
			}	

			if(!empty($filter['filter_name'])){

				$this->db->like($filter['filter_name']['name'],$filter['filter_name']['value']);
				
			}

			if (!empty($filter['from_date'])){
				if ($table_name =='bill' || $table_name =='other_exp')
					$this->db->where($table_name.'.bill_date >=',$filter['from_date']);
				else
					$this->db->where($table_name.'.created_date >=',$filter['from_date']);
			}

			if (!empty($filter['to_date'])){
				if ($table_name =='bill' || $table_name =='other_exp')
					$this->db->where($table_name.'.bill_date <=',$filter['to_date']);
				else
					$this->db->where($table_name.'.created_date <=',$filter['to_date']);
			}

			if (!empty($filter['mod_from_date'])){
				$this->db->where($table_name.'.created_date >=',$filter['mod_from_date']);
			}

			if (!empty($filter['mod_to_date'])){
				$this->db->where($table_name.'.created_date <=',$filter['mod_to_date']);
			}

			// else{
			// 	if ($condition){
			// 		foreach ($condition as $key => $cond) {
			// 			if (!empty($cond['name'])){
			// 				//$this->db->where($cond['name'],$cond['value']);	

			// 				if ($cond['name'] == '$'){
			// 					$this->db->where($cond['value']);	
			// 				}
			// 				else
			// 					$this->db->where($cond['name'],$cond['value']);				
			// 			}
			// 		}
			// 	}
			// }
			if ($condition){
				foreach ($condition as $key => $cond) {
					if (!empty($cond['name'])){
							//$this->db->where($cond['name'],$cond['value']);	
						//echo"<pre>";print_r($cond);exit();
						if ($cond['name'] == 'like' || $cond['name'] == '$'){
							$this->db->where($cond['value']);	
						}
						elseif ($cond['name'] == 'having'){
							$this->db->having($cond['value']);			
						}
						else
							$this->db->where($cond['name'],$cond['value']);				
					}
				}
			}


			if ($active){
			$this->db->where('('.$table_name.".status='1' or ".$table_name.".status='A')"); 
			}

			if ($order){
				foreach ($order as $key => $ord) {
					if (!empty($ord['name'])){
						$this->db->order_by($ord['name'],$ord['value']);						
					}
				}
			}
			// echo $this->db->last_query();exit();

			if ($table_name1 !=''){
				// echo $table_name1;exit();
				$this->db->from($table_name,$table_name1);
				$results = $this->db->get()->result_array();
			}
			else
				$results = $this->db->get($table_name)->result_array();
		}

		//echo $this->db->last_query();exit();
		  //  if ($showqry){
			 // echo $this->db->last_query();exit();
		  //   }
		return $results;
	}
	function save_setting($table_name,$data,$id_return=false){
		$pri_fld_name = $table_name.'_id';

		if(!empty($data[$pri_fld_name])){
			$this->db->where($pri_fld_name,$data[$pri_fld_name]);
			$this->db->update($table_name,$data);
			if ($id_return)
				return $data[$pri_fld_name];		
		}else{
			$this->db->insert($table_name,$data);	
			if ($id_return)
				return $this->db->insert_id();
		}
	} 
	function sort($setting_type,$sort_data=false)
	{
		$id = $setting_type.'_id';
		foreach($sort_data as $key => $data1){
			$this->db->where($id,$data1[$id]);
			$this->db->update($setting_type,$data1);
			// echo $this->db->last_query();exit();
		}	
	}
}
?>