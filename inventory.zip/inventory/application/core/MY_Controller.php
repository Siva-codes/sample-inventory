<?php 

class FrontEnd_Controller extends CI_Controller
{
	function __construct(){
		parent::__construct();
	}
}

class AdminController extends CI_Controller
{
	function __construct(){
		parent::__construct();
		//$this->load->model(array('admin_model'));
		$this->load->library('pagination');

		$cur_cls = $this->router->fetch_class();
		$cur_mth = $this->router->fetch_method();
		// echo $cur_cls;die;

		$exeption_url = $cur_cls=='account' && $cur_mth=='login'?false:true;
		$exeption_url = $cur_cls=='account' && $cur_mth=='logout'?false:$exeption_url;
        $exeption_url = $cur_cls=='app'?false:$exeption_url;
        
		if($exeption_url){
			if(!$this->session->userdata("admin_id")){
				$this->session->set_userdata('admin_redirect_link',current_url());
				redirect('login');
			}
		}
	}
}

?>